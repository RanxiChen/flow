package flow.mmu

import chisel3._
import chisel3.simulator.scalatest.ChiselSim
import flow.core.PRIV_MODE
import flow.interface._
import org.scalatest.freespec.AnyFreeSpec

class BreezeMmuSpec extends AnyFreeSpec with ChiselSim {
  "walk a three-level Sv39 page table and refill the DTLB" in {
    simulate(new BreezeMmu(64, entries = 4)) { dut =>
      dut.io.killI.poke(false.B)
      dut.io.sfence.poke(0.U.asTypeOf(new BreezeSfenceReq(64)))
      dut.io.context.satp.poke(((BigInt(8) << 60) | BigInt(0x100)).U)
      dut.io.context.privilege.poke(PRIV_MODE.S.U)
      dut.io.context.mprv.poke(false.B)
      dut.io.context.mpp.poke(PRIV_MODE.M.U)
      dut.io.context.sum.poke(false.B)
      dut.io.context.mxr.poke(false.B)
      for (n <- 0 until 16) {
        dut.io.context.pmpcfg(n).poke((if (n == 0) 0x0f else 0).U)
        dut.io.context.pmpaddr(n).poke(
          (if (n == 0) (BigInt(1) << 54) - 1 else BigInt(0)).U)
      }
      dut.io.i.req.valid.poke(false.B); dut.io.i.resp.ready.poke(true.B)
      dut.io.d.req.valid.poke(false.B); dut.io.d.resp.ready.poke(true.B)
      dut.io.memReq.ready.poke(true.B)
      dut.io.memRsp.valid.poke(false.B)
      dut.io.memRsp.bits.poke(0.U.asTypeOf(new BackendMemResp))
      dut.reset.poke(true.B); dut.clock.step(2); dut.reset.poke(false.B)

      val va = BigInt("40001234", 16)
      val ptes = Map(
        BigInt("100008", 16) -> ((BigInt(0x101) << 10) | 1),
        BigInt("101000", 16) -> ((BigInt(0x102) << 10) | 1),
        BigInt("102008", 16) -> ((BigInt(0x80001) << 10) | 0xcf))
      dut.io.d.req.bits.vaddr.poke(va.U)
      dut.io.d.req.bits.access.poke(BreezeMmuAccess.Load)
      dut.io.d.req.bits.sizeLog2.poke(3.U)
      dut.io.d.req.valid.poke(true.B)
      while (!dut.io.d.req.ready.peek().litToBoolean) dut.clock.step(1)
      dut.clock.step(1); dut.io.d.req.valid.poke(false.B)

      var guard = 0
      while (!dut.io.d.resp.valid.peek().litToBoolean && guard < 80) {
        if (dut.io.memReq.valid.peek().litToBoolean) {
          val addr = dut.io.memReq.bits.addr.peekValue().asBigInt
          assert(ptes.contains(addr), f"unexpected PTW address 0x$addr%x")
          dut.clock.step(1)
          dut.io.memRsp.bits.valid.poke(true.B)
          dut.io.memRsp.bits.data.poke(ptes(addr).U)
          dut.io.memRsp.bits.isWriteAck.poke(false.B)
          dut.io.memRsp.bits.error.poke(false.B)
          dut.io.memRsp.bits.pageFault.poke(false.B)
          dut.io.memRsp.bits.faultAddr.poke(0.U)
          dut.io.memRsp.valid.poke(true.B)
          dut.clock.step(1)
          dut.io.memRsp.valid.poke(false.B)
        } else dut.clock.step(1)
        guard += 1
      }
      assert(guard < 80)
      dut.io.d.resp.bits.pageFault.expect(false.B)
      dut.io.d.resp.bits.accessFault.expect(false.B)
      dut.io.d.resp.bits.paddr.expect(BigInt("80001234", 16).U)
    }
  }

  "translate a high Sv39 user fetch without sign-extending bit 31" in {
    simulate(new BreezeMmu(64, entries = 4)) { dut =>
      dut.io.killI.poke(false.B)
      dut.io.sfence.poke(0.U.asTypeOf(new BreezeSfenceReq(64)))
      dut.io.context.satp.poke(((BigInt(8) << 60) | BigInt(0x100)).U)
      dut.io.context.privilege.poke(PRIV_MODE.U.U)
      dut.io.context.mprv.poke(false.B)
      dut.io.context.mpp.poke(PRIV_MODE.M.U)
      dut.io.context.sum.poke(false.B)
      dut.io.context.mxr.poke(false.B)
      for (n <- 0 until 16) {
        dut.io.context.pmpcfg(n).poke((if (n == 0) 0x0f else 0).U)
        dut.io.context.pmpaddr(n).poke(
          (if (n == 0) (BigInt(1) << 54) - 1 else BigInt(0)).U)
      }
      dut.io.i.req.valid.poke(false.B); dut.io.i.resp.ready.poke(true.B)
      dut.io.d.req.valid.poke(false.B); dut.io.d.resp.ready.poke(true.B)
      dut.io.memReq.ready.poke(true.B)
      dut.io.memRsp.valid.poke(false.B)
      dut.io.memRsp.bits.poke(0.U.asTypeOf(new BackendMemResp))
      dut.reset.poke(true.B); dut.clock.step(2); dut.reset.poke(false.B)

      val va = BigInt("0000003f92bffbfe", 16)
      val truncated = BigInt("ffffffff92bffbfe", 16)
      val ptes = Map(
        BigInt("1007f0", 16) -> ((BigInt(0x101) << 10) | 1),
        BigInt("1014a8", 16) -> ((BigInt(0x102) << 10) | 1),
        BigInt("102ff8", 16) -> ((BigInt(0x80001) << 10) | 0xdf))
      dut.io.i.req.bits.vaddr.poke(va.U)
      dut.io.i.req.bits.access.poke(BreezeMmuAccess.Fetch)
      dut.io.i.req.bits.sizeLog2.poke(2.U)
      dut.io.i.req.valid.poke(true.B)
      while (!dut.io.i.req.ready.peek().litToBoolean) dut.clock.step(1)
      dut.clock.step(1); dut.io.i.req.valid.poke(false.B)

      var guard = 0
      while (!dut.io.i.resp.valid.peek().litToBoolean && guard < 80) {
        if (dut.io.memReq.valid.peek().litToBoolean) {
          val addr = dut.io.memReq.bits.addr.peekValue().asBigInt
          assert(ptes.contains(addr), f"unexpected PTW address 0x$addr%x")
          dut.clock.step(1)
          dut.io.memRsp.bits.valid.poke(true.B)
          dut.io.memRsp.bits.data.poke(ptes(addr).U)
          dut.io.memRsp.bits.isWriteAck.poke(false.B)
          dut.io.memRsp.bits.error.poke(false.B)
          dut.io.memRsp.bits.pageFault.poke(false.B)
          dut.io.memRsp.bits.faultAddr.poke(0.U)
          dut.io.memRsp.valid.poke(true.B)
          dut.clock.step(1)
          dut.io.memRsp.valid.poke(false.B)
        } else dut.clock.step(1)
        guard += 1
      }
      assert(guard < 80)
      dut.io.i.resp.bits.vaddr.expect(va.U)
      assert(dut.io.i.resp.bits.vaddr.peek().litValue != truncated)
      dut.io.i.resp.bits.pageFault.expect(false.B)
      dut.io.i.resp.bits.accessFault.expect(false.B)
      dut.io.i.resp.bits.paddr.expect(BigInt("80001bfe", 16).U)
    }
  }

  "reject a non-canonical Sv39 address before issuing a PTW request" in {
    simulate(new BreezeMmu(64, entries = 4)) { dut =>
      dut.io.killI.poke(false.B)
      dut.io.sfence.poke(0.U.asTypeOf(new BreezeSfenceReq(64)))
      dut.io.context.poke(0.U.asTypeOf(new BreezeMmuContext(64)))
      dut.io.context.satp.poke((BigInt(8) << 60).U)
      dut.io.context.privilege.poke(PRIV_MODE.S.U)
      dut.io.i.req.valid.poke(false.B); dut.io.i.resp.ready.poke(true.B)
      dut.io.d.req.valid.poke(false.B); dut.io.d.resp.ready.poke(true.B)
      dut.io.memReq.ready.poke(true.B); dut.io.memRsp.valid.poke(false.B)
      dut.io.memRsp.bits.poke(0.U.asTypeOf(new BackendMemResp))
      dut.reset.poke(true.B); dut.clock.step(2); dut.reset.poke(false.B)
      dut.io.i.req.bits.vaddr.poke(BigInt("0000008000000000", 16).U)
      dut.io.i.req.bits.access.poke(BreezeMmuAccess.Fetch)
      dut.io.i.req.bits.sizeLog2.poke(2.U)
      dut.io.i.req.valid.poke(true.B); dut.clock.step(1); dut.io.i.req.valid.poke(false.B)
      while (!dut.io.i.resp.valid.peek().litToBoolean) {
        dut.io.memReq.valid.expect(false.B); dut.clock.step(1)
      }
      dut.io.i.resp.bits.pageFault.expect(true.B)
    }
  }
  "overlapping global and ASID TLB entries select one mapping without merging PPNs" in {
    simulate(new BreezeMmu(64, entries = 4)) { d =>
      d.io.context.poke(0.U.asTypeOf(new BreezeMmuContext(64)))
      d.io.context.privilege.poke(PRIV_MODE.S.U)
      d.io.context.pmpcfg(0).poke(0x0f.U)
      d.io.context.pmpaddr(0).poke(((BigInt(1)<<54)-1).U)
      d.io.killI.poke(false.B)
      d.io.sfence.poke(0.U.asTypeOf(new BreezeSfenceReq(64)))
      d.io.i.req.valid.poke(false.B); d.io.i.resp.ready.poke(true.B)
      d.io.d.req.valid.poke(false.B); d.io.d.resp.ready.poke(true.B)
      d.io.memReq.ready.poke(true.B); d.io.memRsp.valid.poke(false.B)
      d.io.memRsp.bits.poke(0.U.asTypeOf(new BackendMemResp))
      d.reset.poke(true.B); d.clock.step(2); d.reset.poke(false.B)
      for (port <- Seq(d.io.i, d.io.d)) {
        for ((asid, ppn, global, expectedWalks) <- Seq((1,0x80001,false,3), (2,0x80002,true,3), (1,0x80001,false,0))) {
          d.io.context.satp.poke(((BigInt(8)<<60)|(BigInt(asid)<<44)|0x100).U)
          port.req.bits.vaddr.poke(BigInt("40001234",16).U)
          port.req.bits.access.poke(BreezeMmuAccess.Load)
          port.req.bits.sizeLog2.poke(2.U)
          port.req.ready.expect(true.B)
          port.req.valid.poke(true.B); d.clock.step(); port.req.valid.poke(false.B)
          var cycles=0; var walks=0
          val ptes=Map(BigInt(0x100008)->((BigInt(0x101)<<10)|1),
            BigInt(0x101000)->((BigInt(0x102)<<10)|1),
            BigInt(0x102008)->((BigInt(ppn)<<10)|0xcf|(if(global) 0x20 else 0)))
          while(!port.resp.valid.peek().litToBoolean && cycles<80) {
            if(d.io.memReq.valid.peek().litToBoolean) {
              val address=d.io.memReq.bits.addr.peek().litValue
              walks+=1; d.clock.step()
              d.io.memRsp.bits.data.poke(ptes(address).U)
              d.io.memRsp.valid.poke(true.B); d.clock.step(); d.io.memRsp.valid.poke(false.B)
            } else d.clock.step()
            cycles+=1
          }
          assert(cycles<80 && walks==expectedWalks)
          port.resp.bits.pageFault.expect(false.B)
          port.resp.bits.paddr.expect(((BigInt(ppn)<<12)|0x234).U)
          d.clock.step()
        }
      }
    }
  }

  "SFENCE on the leaf refill cycle prevents a stale TLB insertion" in {
    simulate(new BreezeMmu(64, entries = 4)) { d =>
      d.io.context.poke(0.U.asTypeOf(new BreezeMmuContext(64)))
      d.io.context.satp.poke(((BigInt(8)<<60)|0x100).U)
      d.io.context.privilege.poke(PRIV_MODE.S.U)
      d.io.context.pmpcfg(0).poke(0x0f.U)
      d.io.context.pmpaddr(0).poke(((BigInt(1)<<54)-1).U)
      d.io.killI.poke(false.B)
      d.io.sfence.poke(0.U.asTypeOf(new BreezeSfenceReq(64)))
      d.io.i.req.valid.poke(false.B); d.io.i.resp.ready.poke(true.B)
      d.io.d.req.valid.poke(false.B); d.io.d.resp.ready.poke(true.B)
      d.io.memReq.ready.poke(true.B); d.io.memRsp.valid.poke(false.B)
      d.io.memRsp.bits.poke(0.U.asTypeOf(new BackendMemResp))
      d.reset.poke(true.B); d.clock.step(2); d.reset.poke(false.B)
      for (round <- 0 until 2) {
        d.io.i.req.bits.vaddr.poke(BigInt("40001234",16).U)
        d.io.i.req.bits.access.poke(BreezeMmuAccess.Fetch)
        d.io.i.req.bits.sizeLog2.poke(2.U)
        d.io.i.req.ready.expect(true.B)
        d.io.i.req.valid.poke(true.B); d.clock.step(); d.io.i.req.valid.poke(false.B)
        var cycles=0
        while(!d.io.memReq.valid.peek().litToBoolean && cycles<20) {d.clock.step(); cycles+=1}
        assert(cycles<20, "old translation survived SFENCE as a TLB hit")
        d.io.memReq.bits.addr.expect(0x100008.U)
        d.clock.step()
        val ppn=if(round==0) 0x80000 else 0xc0000
        d.io.memRsp.bits.data.poke(((BigInt(ppn)<<10)|0xcf).U)
        d.io.memRsp.valid.poke(true.B); d.clock.step(); d.io.memRsp.valid.poke(false.B)
        // The response has advanced the walker to CheckPte/leaf refill.
        d.io.sfence.valid.poke((round==0).B)
        d.clock.step(); d.io.sfence.valid.poke(false.B)
        if(round==0) d.io.i.resp.valid.expect(false.B)
        else {
          d.io.i.resp.valid.expect(true.B)
          d.io.i.resp.bits.paddr.expect(BigInt("c0001234",16).U)
        }
        d.clock.step()
      }
    }
  }

}
