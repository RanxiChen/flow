package flow.core

import chisel3._
import chisel3.simulator.scalatest.ChiselSim
import flow.config.PrivilegeProfile
import org.scalatest.freespec.AnyFreeSpec
import org.scalatest.matchers.must.Matchers

class BreezePrivilegeSpec extends AnyFreeSpec with Matchers with ChiselSim {
  private def idle(dut: CSRFile): Unit = {
    dut.io.csr_addr.poke(0.U)
    dut.io.csr_cmd.poke(CSR_CMD.NOP.U)
    dut.io.csr_reg_data.poke(0.U)
    dut.io.rs1_id.poke(0.U)
    dut.io.rd_id.poke(0.U)
    dut.io.commit_valid.poke(false.B)
    dut.io.commit_addr.poke(0.U)
    dut.io.commit_wdata.poke(0.U)
    dut.io.commit_write_en.poke(false.B)
    dut.io.fp_commit_valid.poke(false.B)
    dut.io.fp_flags.poke(0.U)
    dut.io.retire_valid.poke(false.B)
    dut.io.hpmEvents.controlRetired.poke(false.B)
    dut.io.hpmEvents.controlTaken.poke(false.B)
    dut.io.hpmEvents.predictionMiss.poke(false.B)
    dut.io.hpmEvents.icacheAccess.poke(false.B)
    dut.io.hpmEvents.icacheMiss.poke(false.B)
    dut.io.hpmEvents.dcacheAccess.poke(false.B)
    dut.io.hpmEvents.dcacheMiss.poke(false.B)
    dut.io.hpmEvents.dcacheUncached.poke(false.B)
    dut.io.hpmEvents.memStallCycle.poke(false.B)
    dut.io.hpmEvents.loadUseStall.poke(false.B)
    dut.io.machineTimerInterrupt.poke(false.B)
    dut.io.machineSoftwareInterrupt.poke(false.B)
    dut.io.machineExternalInterrupt.poke(false.B)
    dut.io.supervisorExternalInterrupt.poke(false.B)
    dut.io.time.poke(0.U)
    dut.io.trap.valid.poke(false.B)
    dut.io.trap.is_interrupt.poke(false.B)
    dut.io.trap.cause.poke(0.U)
    dut.io.trap.pc.poke(0.U)
    dut.io.trap.tval.poke(0.U)
    dut.io.mret_commit.poke(false.B)
    dut.io.sret_commit.poke(false.B)
  }

  private def reset(dut: CSRFile): Unit = {
    idle(dut)
    dut.reset.poke(true.B)
    dut.clock.step(1)
    dut.reset.poke(false.B)
  }

  private def commit(dut: CSRFile, address: Int, value: BigInt): Unit = {
    dut.io.commit_valid.poke(true.B)
    dut.io.commit_write_en.poke(true.B)
    dut.io.commit_addr.poke(address.U)
    dut.io.commit_wdata.poke(value.U)
    dut.clock.step(1)
    dut.io.commit_valid.poke(false.B)
    dut.io.commit_write_en.poke(false.B)
  }

  private def selectRead(dut: CSRFile, address: Int): Unit = {
    dut.io.csr_addr.poke(address.U)
    dut.io.csr_cmd.poke(CSR_CMD.RS.U)
    dut.io.csr_reg_data.poke(0.U)
    dut.io.rs1_id.poke(0.U)
    dut.io.rd_id.poke(1.U)
  }

  private def mret(dut: CSRFile): Unit = {
    dut.io.mret_commit.poke(true.B)
    dut.clock.step(1)
    dut.io.mret_commit.poke(false.B)
  }

  private def sret(dut: CSRFile): Unit = {
    dut.io.sret_commit.poke(true.B)
    dut.clock.step(1)
    dut.io.sret_commit.poke(false.B)
  }

  "SOC3 C1-B: permission events coincide with new CSR and privilege state for exactly one cycle" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      dut.io.mmu_context.permissionEvent.expect(false.B)
      for (address <- Seq(CSRMAP.pmpcfg0, CSRMAP.pmpcfg2) ++
           (0 until 16).map(CSRMAP.pmpaddr0 + _)) {
        commit(dut, address, 0)
        dut.io.mmu_context.permissionEvent.expect(true.B)
        dut.clock.step()
        dut.io.mmu_context.permissionEvent.expect(false.B)
      }
      commit(dut, CSRMAP.mscratch, 123)
      dut.io.mmu_context.permissionEvent.expect(false.B)
      commit(dut, CSRMAP.mstatus, (BigInt(1)<<17) | (BigInt(PRIV_MODE.S)<<11))
      dut.io.mmu_context.permissionEvent.expect(true.B)
      dut.io.mmu_context.mprv.expect(true.B)
      dut.io.mmu_context.mpp.expect(PRIV_MODE.S.U)
      dut.clock.step()
      dut.io.mmu_context.permissionEvent.expect(false.B)
      mret(dut)
      dut.io.mmu_context.permissionEvent.expect(true.B)
      dut.io.mmu_context.privilege.expect(PRIV_MODE.S.U)
      dut.io.mmu_context.mprv.expect(false.B)
      dut.clock.step()
      dut.io.mmu_context.permissionEvent.expect(false.B)
      sret(dut)
      dut.io.mmu_context.permissionEvent.expect(true.B)
      dut.io.mmu_context.privilege.expect(PRIV_MODE.U.U)
      dut.clock.step()
      dut.io.mmu_context.permissionEvent.expect(false.B)
      dut.io.trap.valid.poke(true.B)
      dut.io.mmu_context.permissionEvent.expect(false.B)
      dut.clock.step()
      dut.io.trap.valid.poke(false.B)
      dut.io.mmu_context.permissionEvent.expect(true.B)
      dut.io.mmu_context.privilege.expect(PRIV_MODE.M.U)
      dut.clock.step()
      dut.io.mmu_context.permissionEvent.expect(false.B)
    }
  }

  "keep the MCU profile machine-only and reject supervisor CSRs" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Mcu)) { dut =>
      reset(dut)
      dut.io.current_privilege.expect(PRIV_MODE.M.U)
      selectRead(dut, CSRMAP.misa)
      val misa = dut.io.csr_old_data.peek().litValue
      ((misa >> 18) & 1) mustBe 0
      ((misa >> 20) & 1) mustBe 0

      selectRead(dut, CSRMAP.sstatus)
      dut.io.csr_illegal.expect(true.B)
      dut.io.sret_illegal.expect(true.B)
    }
  }

  "reject every unimplemented MCU CSR instead of silently reading zero" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Mcu)) { dut =>
      reset(dut)
      commit(dut, CSRMAP.mstatus, BigInt(1) << 13)

      val implemented = Set(
        CSRMAP.fflags, CSRMAP.frm, CSRMAP.fcsr, CSRMAP.printer, CSRMAP.coreinst,
        CSRMAP.misa, CSRMAP.mvendorid, CSRMAP.marchid, CSRMAP.mimpid, CSRMAP.mhartid,
        CSRMAP.mstatus, CSRMAP.mie, CSRMAP.mtvec, CSRMAP.mcounteren,
        CSRMAP.mscratch, CSRMAP.mepc, CSRMAP.mcause, CSRMAP.mtval, CSRMAP.mip,
        CSRMAP.mcycle, CSRMAP.minstret, CSRMAP.cycle, CSRMAP.time, CSRMAP.instret,
        CSRMAP.mcountinhibit, CSRMAP.menvcfg, CSRMAP.pmpcfg0, CSRMAP.pmpcfg2,
        CSRMAP.tselect, CSRMAP.tdata1, CSRMAP.tdata2
      ) ++ (0 until 16).map(CSRMAP.pmpaddr0 + _) ++
        (0 until 8).flatMap(index => Seq(
          CSRMAP.mhpmcounter3 + index,
          CSRMAP.hpmcounter3 + index,
          CSRMAP.mhpmevent3 + index))

      for (address <- 0 until 4096) {
        selectRead(dut, address)
        val expectedIllegal = !implemented.contains(address)
        withClue(f"MCU CSR 0x$address%03x: ") {
          (dut.io.csr_illegal.peek().litValue != 0) mustBe expectedIllegal
        }
      }
    }
  }

  "check OpenSBI extension probes and reject every unimplemented Linux CSR" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)

      // Make dynamically gated implemented CSRs readable before checking the
      // static address whitelist: FS=Initial enables fflags/frm/fcsr.
      // M-mode stimecmp access does not depend on STCE.
      commit(dut, CSRMAP.mstatus, BigInt(1) << 13)
      commit(dut, CSRMAP.menvcfg, BigInt(1) << 63)

      val implemented = Set(
        CSRMAP.fflags, CSRMAP.frm, CSRMAP.fcsr, CSRMAP.printer, CSRMAP.coreinst,
        CSRMAP.misa, CSRMAP.mvendorid, CSRMAP.marchid, CSRMAP.mimpid, CSRMAP.mhartid,
        CSRMAP.mstatus, CSRMAP.medeleg, CSRMAP.mideleg, CSRMAP.mie, CSRMAP.mtvec,
        CSRMAP.mcounteren, CSRMAP.mscratch, CSRMAP.mepc, CSRMAP.mcause, CSRMAP.mtval,
        CSRMAP.mip, CSRMAP.mcycle, CSRMAP.minstret, CSRMAP.cycle, CSRMAP.time,
        CSRMAP.instret, CSRMAP.mcountinhibit, CSRMAP.menvcfg, CSRMAP.pmpcfg0,
        CSRMAP.pmpcfg2, CSRMAP.tselect, CSRMAP.tdata1, CSRMAP.tdata2,
        CSRMAP.sstatus, CSRMAP.sie, CSRMAP.stvec, CSRMAP.scounteren,
        CSRMAP.sscratch, CSRMAP.sepc, CSRMAP.scause, CSRMAP.stval, CSRMAP.sip,
        CSRMAP.stimecmp, CSRMAP.satp
      ) ++ (0 until 16).map(CSRMAP.pmpaddr0 + _) ++
        (0 until 8).flatMap(index => Seq(
          CSRMAP.mhpmcounter3 + index,
          CSRMAP.hpmcounter3 + index,
          CSRMAP.mhpmevent3 + index))

      // The R2 trigger contract exposes only these three M-mode CSRs, with
      // zero reads and ignored writes. Other trigger CSRs remain illegal.
      val openSbiProbes = Seq(
        (0xfb0, "mtopi/Smaia", true),
        (0xda0, "scountovf/Sscofpmf", true),
        (0x30c, "mstateen0/Smstateen", true),
        (0x10c, "sstateen0/Ssstateen", true),
        (0x321, "mcyclecfg/Smcntrpmf", true),
        (CSRMAP.tselect, "tselect/Sdtrig", false),
        (CSRMAP.tdata1, "tdata1/Sdtrig", false),
        (CSRMAP.tdata2, "tdata2/Sdtrig", false),
        (0x7a3, "tdata3/Sdtrig", true),
        (0x7a4, "tinfo/Sdtrig", true),
        (0x7a5, "tcontrol/Sdtrig", true))
      openSbiProbes.foreach { case (address, name, expectedIllegal) =>
        selectRead(dut, address)
        withClue(s"OpenSBI probe $name at 0x${address.toHexString}: ") {
          (dut.io.csr_illegal.peek().litValue != 0) mustBe expectedIllegal
          if (!expectedIllegal) dut.io.csr_old_data.expect(0.U)
        }
      }

      for (address <- 0 until 4096) {
        selectRead(dut, address)
        val expectedIllegal = !implemented.contains(address)
        withClue(f"CSR 0x$address%03x: ") {
          (dut.io.csr_illegal.peek().litValue != 0) mustBe expectedIllegal
        }
      }
    }
  }

  "enter S and U with MRET/SRET and route delegated exceptions to S" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      selectRead(dut, CSRMAP.misa)
      val misa = dut.io.csr_old_data.peek().litValue
      ((misa >> 18) & 1) mustBe 1
      ((misa >> 20) & 1) mustBe 1

      commit(dut, CSRMAP.stvec, 0x400)
      commit(dut, CSRMAP.medeleg, BigInt(1) << 8)
      commit(dut, CSRMAP.mepc, 0x1000)
      commit(dut, CSRMAP.mstatus, BigInt(PRIV_MODE.S) << 11)
      dut.io.xret_target.expect(0x1000.U)
      mret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)

      for (address <- Seq(CSRMAP.tselect, CSRMAP.tdata1, CSRMAP.tdata2)) {
        selectRead(dut, address)
        dut.io.csr_illegal.expect(true.B)
      }

      commit(dut, CSRMAP.sepc, 0x2000)
      commit(dut, CSRMAP.sstatus, 0)
      sret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.U.U)

      for (address <- Seq(CSRMAP.tselect, CSRMAP.tdata1, CSRMAP.tdata2)) {
        selectRead(dut, address)
        dut.io.csr_illegal.expect(true.B)
      }

      selectRead(dut, CSRMAP.sstatus)
      dut.io.csr_illegal.expect(true.B)
      selectRead(dut, CSRMAP.mstatus)
      dut.io.csr_illegal.expect(true.B)

      dut.io.csr_cmd.poke(CSR_CMD.NOP.U)
      dut.io.trap.valid.poke(true.B)
      dut.io.trap.is_interrupt.poke(false.B)
      dut.io.trap.cause.poke(8.U)
      dut.io.trap.pc.poke(0x2344.U)
      dut.io.trap.tval.poke(0.U)
      dut.io.trap_target.expect(0x400.U)
      dut.clock.step(1)
      dut.io.trap.valid.poke(false.B)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)

      selectRead(dut, CSRMAP.sepc)
      dut.io.csr_illegal.expect(false.B)
      dut.io.csr_old_data.expect(0x2344.U)
      selectRead(dut, CSRMAP.scause)
      dut.io.csr_old_data.expect(8.U)

      commit(dut, CSRMAP.satp, BigInt("8000000000001234", 16))
      selectRead(dut, CSRMAP.satp)
      dut.io.csr_old_data.expect(BigInt("8000000000001234", 16).U)
    }
  }

  "preserve a high Sv39 user address across sepc and SRET" in {
    simulate(new CSRFile(64, enableCompressed = true,
      privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val target = BigInt("0000003f92bffbfe", 16)
      val truncated = BigInt("ffffffff92bffbfe", 16)

      commit(dut, CSRMAP.mepc, 0x1000)
      commit(dut, CSRMAP.mstatus, BigInt(PRIV_MODE.S) << 11)
      mret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)

      commit(dut, CSRMAP.sepc, target)
      selectRead(dut, CSRMAP.sepc)
      dut.io.csr_old_data.expect(target.U)
      dut.io.csr_old_data.peek().litValue must not be truncated

      dut.io.csr_cmd.poke(CSR_CMD.NOP.U)
      dut.io.sret_commit.poke(true.B)
      dut.io.xret_target.expect(target.U)
      dut.io.xret_target.peek().litValue must not be truncated
      dut.clock.step(1)
      dut.io.sret_commit.poke(false.B)
      dut.io.current_privilege.expect(PRIV_MODE.U.U)
    }
  }

  "take a delegated supervisor software interrupt with vectored stvec" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val ssip = BigInt(1) << SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE
      commit(dut, CSRMAP.stvec, 0x401)
      commit(dut, CSRMAP.mideleg, ssip)
      commit(dut, CSRMAP.mie, ssip)
      commit(dut, CSRMAP.mip, ssip)
      commit(dut, CSRMAP.mepc, 0x1000)
      commit(dut, CSRMAP.mstatus, 0)
      mret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.U.U)
      dut.io.interruptPending.expect(true.B)
      dut.io.interruptCause.expect(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE.U)

      dut.io.trap.valid.poke(true.B)
      dut.io.trap.is_interrupt.poke(true.B)
      dut.io.trap.cause.poke(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE.U)
      dut.io.trap.pc.poke(0x1234.U)
      dut.io.trap_target.expect(0x404.U)
      dut.clock.step(1)
      dut.io.trap.valid.poke(false.B)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)
    }
  }

  "wake WFI from a locally enabled interrupt independently of global MIE" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val msip = BigInt(1) << MACHINE_INTERRUPT_CAUSE.SOFTWARE

      commit(dut, CSRMAP.mie, msip)
      commit(dut, CSRMAP.mstatus, 0)
      dut.io.machineSoftwareInterrupt.poke(true.B)
      dut.io.wfiWakeup.expect(true.B)
      dut.io.interruptPending.expect(false.B)

      commit(dut, CSRMAP.mstatus, BigInt(1) << 3)
      dut.io.wfiWakeup.expect(true.B)
      dut.io.interruptPending.expect(true.B)

      dut.io.machineSoftwareInterrupt.poke(false.B)
      dut.io.wfiWakeup.expect(false.B)
      dut.io.interruptPending.expect(false.B)
    }
  }

  "enforce TSR TW TVM and keep simulation CSRs machine-only" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val trapControls = (BigInt(1) << 22) | (BigInt(1) << 21) |
        (BigInt(1) << 20)
      commit(dut, CSRMAP.mepc, 0x1000)
      commit(dut, CSRMAP.mstatus, trapControls | (BigInt(PRIV_MODE.S) << 11))

      selectRead(dut, CSRMAP.mstatus)
      val mstatus = dut.io.csr_old_data.peek().litValue
      ((mstatus >> 34) & 3) mustBe 2 // SXL=64
      ((mstatus >> 32) & 3) mustBe 2 // UXL=64

      mret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)
      dut.io.sret_illegal.expect(true.B)
      dut.io.wfi_illegal.expect(true.B)
      dut.io.sfence_vma_illegal.expect(true.B)

      selectRead(dut, CSRMAP.sstatus)
      ((dut.io.csr_old_data.peek().litValue >> 32) & 3) mustBe 2
      selectRead(dut, CSRMAP.satp)
      dut.io.csr_illegal.expect(true.B)
      selectRead(dut, CSRMAP.printer)
      dut.io.csr_illegal.expect(true.B)
      selectRead(dut, CSRMAP.coreinst)
      dut.io.csr_illegal.expect(true.B)
    }
  }

  "decode WFI and SFENCE.VMA as privilege-checked system operations" in {
    simulate(new RV64IZicsrDecoder) { dut =>
      dut.io.inst.poke("h10500073".U) // WFI
      dut.io.illegal_inst.expect(false.B)
      dut.io.I_ctrl.is_wfi.expect(true.B)
      dut.io.I_ctrl.is_sfence_vma.expect(false.B)

      dut.io.inst.poke("h12000073".U) // SFENCE.VMA x0, x0
      dut.io.illegal_inst.expect(false.B)
      dut.io.I_ctrl.is_wfi.expect(false.B)
      dut.io.I_ctrl.is_sfence_vma.expect(true.B)
    }
  }

  "decode EBREAK as a breakpoint exception instead of an illegal instruction" in {
    simulate(new RV64IZicsrDecoder) { dut =>
      dut.io.inst.poke("h00100073".U)
      dut.io.illegal_inst.expect(false.B)
      dut.io.I_ctrl.is_ebreak.expect(true.B)
      dut.io.I_ctrl.is_ecall.expect(false.B)

      dut.io.inst.poke("h00108073".U) // Reserved encoding: rs1 must be x0.
      dut.io.illegal_inst.expect(true.B)
      dut.io.I_ctrl.is_ebreak.expect(false.B)
    }
  }

  "expose eight writable PMP entries and eight read-zero slots to firmware probes" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val addrMask = (BigInt(1) << 54) - 1
      var detected = 0
      for (index <- 0 until 16) {
        commit(dut, CSRMAP.pmpaddr0 + index, addrMask)
        selectRead(dut, CSRMAP.pmpaddr0 + index)
        dut.io.csr_illegal.expect(false.B)
        val expected = if (index < 8) addrMask else BigInt(0)
        dut.io.csr_old_data.expect(expected.U)
        dut.io.mmu_context.pmpaddr(index).expect(expected.U)
        if (dut.io.csr_old_data.peek().litValue == addrMask) detected += 1
      }
      detected mustBe 8

      // Attempts to configure/lock entry 8 cannot change or lock entry 7.
      commit(dut, CSRMAP.pmpcfg2, BigInt("ffffffffffffffff", 16))
      selectRead(dut, CSRMAP.pmpcfg2)
      dut.io.csr_illegal.expect(false.B)
      dut.io.csr_old_data.expect(0.U)
      for (index <- 8 until 16) dut.io.mmu_context.pmpcfg(index).expect(0.U)
      commit(dut, CSRMAP.pmpaddr0 + 7, 0x1234)
      selectRead(dut, CSRMAP.pmpaddr0 + 7)
      dut.io.csr_old_data.expect(0x1234.U)

      // A locked TOR entry 7 still locks its own address and entry 6's bound.
      commit(dut, CSRMAP.pmpcfg0, BigInt(0x89) << 56)
      commit(dut, CSRMAP.pmpaddr0 + 6, 0)
      commit(dut, CSRMAP.pmpaddr0 + 7, 0)
      selectRead(dut, CSRMAP.pmpaddr0 + 6)
      dut.io.csr_old_data.expect(addrMask.U)
      selectRead(dut, CSRMAP.pmpaddr0 + 7)
      dut.io.csr_old_data.expect(0x1234.U)
      commit(dut, CSRMAP.pmpcfg0, 0)
      selectRead(dut, CSRMAP.pmpcfg0)
      dut.io.csr_old_data.expect((BigInt(0x89) << 56).U)
    }
  }

  "SOC3d PMP predecode changes on the CSR edge and preserves TOR predecessor locks" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { d =>
      reset(d)
      def bounds(n: Int, lo: BigInt, hi: BigInt, nonempty: Boolean): Unit = {
        val r = d.io.mmu_context.pmpRanges(n)
        d.io.mmu_context.pmpRangesValid.expect(true.B)
        r.lower.expect(lo.U); r.upper.expect(hi.U); r.nonempty.expect(nonempty.B)
        val blockMask = (BigInt(1) << 58) - 1
        r.lowerBlockPrevious.expect((((lo >> 7) - 1) & blockMask).U)
        r.upperBlockPrevious.expect((((hi >> 7) - 1) & blockMask).U)
      }
      commit(d, CSRMAP.pmpaddr0, 0x20)
      commit(d, CSRMAP.pmpaddr0 + 1, 0x60)
      commit(d, CSRMAP.pmpcfg0, 0x0f00)
      bounds(1, 0x80, 0x180, true)
      commit(d, CSRMAP.pmpaddr0, 0x40)
      bounds(1, 0x100, 0x180, true)
      commit(d, CSRMAP.pmpcfg0, 0x8f00)
      commit(d, CSRMAP.pmpaddr0, 0)
      commit(d, CSRMAP.pmpaddr0 + 1, 0)
      commit(d, CSRMAP.pmpcfg0, 0)
      bounds(1, 0x100, 0x180, true)
      d.io.mmu_context.pmpaddr(0).expect(0x40.U)
      // An unlocked NA4 entry and then a NAPOT entry decode their new bounds.
      commit(d, CSRMAP.pmpaddr0 + 2, 0x80)
      commit(d, CSRMAP.pmpcfg0, BigInt(0x17) << 16)
      bounds(2, 0x200, 0x204, true)
      commit(d, CSRMAP.pmpaddr0 + 2, 0x8f)
      commit(d, CSRMAP.pmpcfg0, BigInt(0x1f) << 16)
      bounds(2, 0x200, 0x280, true)
      d.clock.step(3)
    }
  }
  // Integer interval oracle: derive NAPOT size from trailing address ones,
  // independently of the hardware decoder's XOR/mask arithmetic.
  private def expectPmpState(d: CSRFile, cfg: Seq[Int], addr: Seq[BigInt]): Unit = {
    d.io.mmu_context.pmpRangesValid.expect(true.B)
    for (n <- 0 until 8) {
      d.io.mmu_context.pmpcfg(n).expect(cfg(n).U)
      d.io.mmu_context.pmpaddr(n).expect(addr(n).U)
      val mode = (cfg(n) >> 3) & 3
      val boundary = addr(n) << 2
      val (lo, hi) = mode match {
        case 0 | 1 => (if (n == 0) BigInt(0) else addr(n - 1) << 2, boundary)
        case 2 => (boundary, boundary + 4)
        case 3 =>
          val trailingOnes = (0 until 54).takeWhile(addr(n).testBit).size
          val bytes = BigInt(1) << (trailingOnes + 3)
          val base = boundary / bytes * bytes
          (base, base + bytes)
      }
      val r = d.io.mmu_context.pmpRanges(n)
      r.lower.expect(lo.U); r.upper.expect(hi.U)
      r.nonempty.expect((mode != 0 && lo < hi).B)
      val blockMask = (BigInt(1) << 58) - 1
      r.lowerBlockPrevious.expect((((lo >> 7) - 1) & blockMask).U)
      r.upperBlockPrevious.expect((((hi >> 7) - 1) & blockMask).U)
    }
    for (n <- 8 until 16) {
      d.io.mmu_context.pmpcfg(n).expect(0.U)
      d.io.mmu_context.pmpaddr(n).expect(0.U)
    }
  }

  "SOC3d-control PMP candidates cannot change state without valid write or during trap" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { d =>
      reset(d)
      commit(d, CSRMAP.pmpaddr0, 0x20)
      commit(d, CSRMAP.pmpaddr0 + 1, 0x60)
      commit(d, CSRMAP.pmpcfg0, 0x0f00)
      val cfg = Seq(0, 0x0f) ++ Seq.fill(6)(0)
      val addr = Seq(BigInt(0x20), BigInt(0x60)) ++ Seq.fill(6)(BigInt(0))
      d.clock.step(2)
      for ((valid, write, trap) <- Seq((false, true, false), (true, false, false),
          (true, true, true), (false, false, true));
           (address, value) <- Seq(CSRMAP.pmpcfg0 -> BigInt("ffffffffffffffff", 16),
             CSRMAP.pmpaddr0 -> BigInt(0x70), (CSRMAP.pmpaddr0 + 1) -> BigInt(0x10))) {
        withClue(s"valid=$valid write=$write trap=$trap csr=$address: ") {
          d.io.commit_valid.poke(valid.B); d.io.commit_write_en.poke(write.B)
          d.io.commit_addr.poke(address.U); d.io.commit_wdata.poke(value.U)
          d.io.trap.valid.poke(trap.B); d.io.trap.cause.poke(2.U)
          d.io.trap.pc.poke(0x100.U)
          expectPmpState(d, cfg, addr) // No combinational architectural leakage.
          for (_ <- 0 until 3) {
            d.clock.step(); expectPmpState(d, cfg, addr)
            d.io.mmu_context.permissionEvent.expect(trap.B)
          }
        }
      }
      idle(d)
      // A blocked lock-bit candidate must not have secretly locked the bank.
      commit(d, CSRMAP.pmpaddr0, 0x40)
      expectPmpState(d, cfg, addr.updated(0, BigInt(0x40)))
      commit(d, CSRMAP.pmpcfg0, 0x1f00)
      expectPmpState(d, cfg.updated(1, 0x1f), addr.updated(0, BigInt(0x40)))
      d.clock.step(2)
    }
  }

  "SOC3d-control consecutive PMP writes keep raw state and ranges aligned through WARL and locks" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { d =>
      reset(d)
      val cfg = Array.fill(8)(0)
      val addr = Array.fill(8)(BigInt(0))
      val rng = new scala.util.Random(0x3d504d51)
      val randomWrites = (0 until 32).map { n =>
        if (n % 4 == 0) {
          val bytes = (0 until 8).map(_ => rng.nextInt(128)) // Lock explicitly below.
          CSRMAP.pmpcfg0 -> bytes.zipWithIndex.foldLeft(BigInt(0)) {
            case (word, (byte, lane)) => word | (BigInt(byte) << (8 * lane))
          }
        } else (CSRMAP.pmpaddr0 + rng.nextInt(8)) -> BigInt(rng.nextInt(0x400))
      }
      val writes = Seq(CSRMAP.pmpaddr0 -> BigInt(0x20),
        (CSRMAP.pmpaddr0 + 1) -> BigInt(0x60), CSRMAP.pmpcfg0 -> BigInt(0x0f00),
        CSRMAP.pmpaddr0 -> BigInt(0x80), CSRMAP.pmpaddr0 -> BigInt(0x40)) ++
        randomWrites ++ Seq(CSRMAP.pmpcfg0 -> BigInt(0x978f00),
          CSRMAP.pmpaddr0 -> BigInt(1), (CSRMAP.pmpaddr0 + 1) -> BigInt(2),
          (CSRMAP.pmpaddr0 + 2) -> BigInt(3), CSRMAP.pmpcfg0 -> BigInt(0),
          CSRMAP.pmpcfg2 -> BigInt("ffffffffffffffff", 16),
          (CSRMAP.pmpaddr0 + 8) -> BigInt(0x1234))
      for ((address, value) <- writes) {
        expectPmpState(d, cfg.toSeq, addr.toSeq)
        d.io.commit_valid.poke(true.B); d.io.commit_write_en.poke(true.B)
        d.io.commit_addr.poke(address.U); d.io.commit_wdata.poke(value.U)
        if (address == CSRMAP.pmpcfg0) {
          for (n <- 0 until 8 if (cfg(n) & 0x80) == 0) {
            val byte = ((value >> (8 * n)) & 0x9f).toInt
            cfg(n) = if ((byte & 1) == 0) byte & ~2 else byte
          }
        } else if (address >= CSRMAP.pmpaddr0 && address < CSRMAP.pmpaddr0 + 8) {
          val n = address - CSRMAP.pmpaddr0
          val locked = (cfg(n) & 0x80) != 0 ||
            (n < 7 && (cfg(n + 1) & 0x98) == 0x88)
          if (!locked) addr(n) = value & ((BigInt(1) << 54) - 1)
        }
        d.clock.step() // No idle edge between writes; check immediately.
        expectPmpState(d, cfg.toSeq, addr.toSeq)
      }
      idle(d); d.clock.step(3)
      expectPmpState(d, cfg.toSeq, addr.toSeq)
    }
  }
  "implement PMP CSRs and Sstc time/stimecmp pending state" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      commit(dut, CSRMAP.pmpaddr0, (BigInt(1) << 54) - 1)
      commit(dut, CSRMAP.pmpcfg0, 0x0f)
      selectRead(dut, CSRMAP.pmpaddr0)
      dut.io.csr_old_data.expect(((BigInt(1) << 54) - 1).U)
      selectRead(dut, CSRMAP.pmpcfg0)
      dut.io.csr_old_data.expect(0x0f.U)

      commit(dut, CSRMAP.menvcfg, (BigInt(1) << 63) | (BigInt(1) << 61))
      commit(dut, CSRMAP.mideleg, BigInt(1) << SUPERVISOR_INTERRUPT_CAUSE.TIMER)
      commit(dut, CSRMAP.stimecmp, 100)
      dut.io.time.poke(99.U)
      selectRead(dut, CSRMAP.sip)
      dut.io.csr_old_data.expect(0.U)
      dut.io.time.poke(100.U)
      selectRead(dut, CSRMAP.sip)
      assert((dut.io.csr_old_data.peekValue().asBigInt & (BigInt(1) << 5)) != 0)
    }
  }
  "trap entry dominates a simultaneous return request" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { d =>
      for (supervisorReturn <- Seq(false, true)) {
        reset(d)
        commit(d, CSRMAP.mstatus, 0) // saved MPP/SPP would return to U
        d.io.trap.valid.poke(true.B)
        d.io.trap.pc.poke(0x234.U); d.io.trap.cause.poke(2.U)
        d.io.mret_commit.poke((!supervisorReturn).B)
        d.io.sret_commit.poke(supervisorReturn.B)
        d.clock.step()
        idle(d)
        d.io.current_privilege.expect(PRIV_MODE.M.U)
        selectRead(d, CSRMAP.mepc); d.io.csr_old_data.expect(0x234.U)
      }
    }
  }


  "forward the OpenSBI software timer interrupt and clear it on rearming" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      commit(dut, CSRMAP.mideleg, 0x20)
      commit(dut, CSRMAP.mie, 0x20)
      commit(dut, CSRMAP.mstatus, (BigInt(1) << 11) | 2) // return to S, SIE=1
      commit(dut, CSRMAP.mip, 0x20)
      dut.io.interruptPending.expect(false.B) // delegated interrupt masked in M
      mret(dut)
      dut.io.interruptPending.expect(true.B)
      dut.io.interruptCause.expect(5.U)
      selectRead(dut, CSRMAP.sip)
      dut.io.csr_old_data.expect(0x20.U)
      commit(dut, CSRMAP.sip, 0) // STIP is read-only through sip
      dut.io.interruptPending.expect(true.B)
      // Model the subsequent M-mode SBI timer handler's committed CSR write.
      commit(dut, CSRMAP.mip, 0)
      dut.io.interruptPending.expect(false.B)
    }
  }

  "preserve hidden interrupt bits and prioritize M destinations over S" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      commit(dut, CSRMAP.mie, 0x222)
      commit(dut, CSRMAP.mip, 0x222)
      commit(dut, CSRMAP.sie, 0)
      commit(dut, CSRMAP.sip, 0)
      selectRead(dut, CSRMAP.mie)
      dut.io.csr_old_data.expect(0x222.U)
      selectRead(dut, CSRMAP.mip)
      dut.io.csr_old_data.expect(0x222.U)
      commit(dut, CSRMAP.mideleg, 0x202) // SEI/SSI to S; STI to M
      commit(dut, CSRMAP.mstatus, (BigInt(1) << 11) | 2)
      mret(dut)
      dut.io.interruptPending.expect(true.B)
      dut.io.interruptCause.expect(5.U) // M-targeted STI beats S-targeted SEI
      commit(dut, CSRMAP.mip, 0x202)
      dut.io.interruptCause.expect(9.U)
    }
  }

  "exclude the external SEIP wire from CSRRS and CSRRC writeback" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      dut.io.supervisorExternalInterrupt.poke(true.B)
      for (cmd <- Seq(CSR_CMD.RS, CSR_CMD.RC, CSR_CMD.RSI, CSR_CMD.RCI)) {
        selectRead(dut, CSRMAP.mip)
        dut.io.csr_cmd.poke(cmd.U)
        dut.io.rs1_id.poke(1.U)
        dut.io.csr_reg_data.poke(2.U)
        dut.io.csr_old_data.expect(0x200.U)
        val written = dut.io.csr_new_data.peek().litValue
        (written & 0x200) mustBe 0
      }
      commit(dut, CSRMAP.mip, 0x200)
      dut.io.supervisorExternalInterrupt.poke(false.B)
      selectRead(dut, CSRMAP.mip)
      dut.io.csr_old_data.expect(0x200.U)
      commit(dut, CSRMAP.mip, 0)
      dut.io.csr_old_data.expect(0.U)
    }
  }

  "allow M stimecmp access and require both STCE and TM for S" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      selectRead(dut, CSRMAP.stimecmp)
      dut.io.csr_illegal.expect(false.B)
      commit(dut, CSRMAP.stimecmp, 100)
      dut.io.csr_old_data.expect(100.U)
      commit(dut, CSRMAP.mstatus, BigInt(1) << 11)
      mret(dut)
      dut.io.csr_illegal.expect(true.B)
      // Commit interface models authorized firmware writes, not instruction decode.
      commit(dut, CSRMAP.menvcfg, BigInt(1) << 63)
      dut.io.csr_illegal.expect(true.B)
      commit(dut, CSRMAP.mcounteren, 2)
      dut.io.csr_illegal.expect(false.B)
      dut.io.time.poke(100.U)
      commit(dut, CSRMAP.mideleg, 0x20)
      selectRead(dut, CSRMAP.sip)
      dut.io.csr_old_data.expect(0x20.U)
      commit(dut, CSRMAP.mip, 0) // comparator owns STIP while STCE=1
      dut.io.csr_old_data.expect(0x20.U)
    }
  }

  "preserve satp on unsupported modes and clear MPRV on SRET" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      val original = (BigInt(8) << 60) | (BigInt(0x1234) << 44) | 0x80000
      commit(dut, CSRMAP.satp, original)
      commit(dut, CSRMAP.satp, (BigInt(9) << 60) | 0x90000)
      selectRead(dut, CSRMAP.satp)
      dut.io.csr_old_data.expect(original.U)
      commit(dut, CSRMAP.mstatus, (BigInt(1) << 17) | (BigInt(1) << 8))
      sret(dut)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)
      dut.io.mmu_context.mprv.expect(false.B)
    }
  }

  "delegate user breakpoints to the supervisor handler" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { dut =>
      reset(dut)
      commit(dut, CSRMAP.medeleg, 8)
      commit(dut, CSRMAP.stvec, 0x400)
      commit(dut, CSRMAP.mstatus, 0) // MRET to U
      mret(dut)
      dut.io.trap.valid.poke(true.B)
      dut.io.trap.cause.poke(3.U)
      dut.io.trap.pc.poke(0x1000.U)
      dut.io.trap_target.expect(0x400.U)
      dut.clock.step()
      dut.io.trap.valid.poke(false.B)
      dut.io.current_privilege.expect(PRIV_MODE.S.U)
      selectRead(dut, CSRMAP.scause)
      dut.io.csr_old_data.expect(3.U)
    }
  }
  "SOC3d-combined Sstc compare preserves same-cycle pending across every byte boundary and rearm" in {
    simulate(new CSRFile(64, privilegeProfile = PrivilegeProfile.Linux)) { d =>
      reset(d)
      commit(d, CSRMAP.menvcfg, BigInt(1) << 63)
      commit(d, CSRMAP.mideleg, BigInt(1) << 5)
      val max = (BigInt(1) << 64) - 1
      val rng = new scala.util.Random(0x3dc04L)
      val thresholds = Seq(BigInt(0),max,BigInt(1) << 63) ++
        (8 until 64 by 8).flatMap(n => Seq((BigInt(1)<<n)-1,BigInt(1)<<n)) ++
        Seq.fill(32)(BigInt(64,rng))
      for (threshold <- thresholds) {
        commit(d, CSRMAP.stimecmp, threshold)
        for (now <- Seq((threshold-1)&max,threshold,(threshold+1)&max,BigInt(64,rng))) {
          d.io.time.poke(now.U); selectRead(d, CSRMAP.sip)
          ((d.io.csr_old_data.peek().litValue >> 5) & 1) mustBe (if(now >= threshold) BigInt(1) else BigInt(0))
        }
      }
      d.io.time.poke(100.U); commit(d, CSRMAP.stimecmp,99)
      selectRead(d, CSRMAP.sip); ((d.io.csr_old_data.peek().litValue >> 5)&1) mustBe BigInt(1)
      commit(d, CSRMAP.stimecmp,101)
      selectRead(d, CSRMAP.sip); ((d.io.csr_old_data.peek().litValue >> 5)&1) mustBe BigInt(0)
      commit(d, CSRMAP.menvcfg,0); commit(d, CSRMAP.mip,BigInt(1)<<5)
      selectRead(d, CSRMAP.sip); ((d.io.csr_old_data.peek().litValue >> 5)&1) mustBe BigInt(1)
    }
  }

}
