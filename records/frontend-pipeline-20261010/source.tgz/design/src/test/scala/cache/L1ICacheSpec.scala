package flow.cache

import chisel3._
import chisel3.experimental.BundleLiterals._
import chisel3.simulator.scalatest.ChiselSim
import org.scalatest.freespec.AnyFreeSpec
import org.scalatest.matchers.must.Matchers
import flow.l1i.{L1ICache, L1IParams}

class L1ICacheSpec extends AnyFreeSpec with Matchers with ChiselSim {
    val cfg = L1IParams()
    def sendCacheReq(dut: L1ICache, vaddr: BigInt): Unit = {
        dut.io.dreq.valid.poke(true.B)
        dut.io.dreq.bits.vaddr.poke(vaddr.U)
        dut.io.dreq.bits.paddr.poke(vaddr.U)
        println(s"[INFO] Sending request for vaddr: 0x${vaddr.toString(16)}")
    }
    "L1ICache should miss after reset" in {
        simulate(new L1ICache(cfg, enabledebug = true)){dut =>
            var cycle_count = 0
            var s2Cycle = 0
            val lineBase = BigInt(0x10000000L)
            val refillLine = BigInt("1f1e1d1c1b1a191817161514131211100f0e0d0c0b0a09080706050403020100", 16)
            // defaultly, chiseltest will auto reset the dut, so we can directly check the initial state
            dut.io.flush.poke(false.B)
            dut.io.drsp.ready.poke(true.B)
            dut.io.next_level_rsp.vld.poke(false.B)
            dut.io.next_level_rsp.data.poke(0.U)
            sendCacheReq(dut, lineBase)
            println(s"[INFO] cycle 0")
            println(s"[INFO] cycle ${cycle_count} , s0 should valid")
            assert(dut.io.debug.get.s0_valid.peek().litToBoolean, "debug.s0_valid should be asserted after sendCacheReq")
            assert(dut.io.debug.get.s0_vaddr.peek().litValue == lineBase, "debug.s0_vaddr should match the requested address")
            dut.clock.step(1)
            cycle_count += 1
            println(s"[INFO] cycle 1")
            println(s"[INFO] cycle ${cycle_count} , s1 should valid")
            assert(dut.io.debug.get.s1_valid.peek().litToBoolean, "debug.s1_valid should be asserted one cycle after sendCacheReq")
            assert(dut.io.debug.get.s1_vaddr.peek().litValue == lineBase, "debug.s1_vaddr should match the requested address")
            println(s"[INFO] s1_tag_hit = 0x${dut.io.debug.get.s1_tag_hit.peek().litValue.toString(16)}")
            println(s"[INFO] s1_hit = ${dut.io.debug.get.s1_hit.peek().litToBoolean}")
            println(s"[INFO] cycle ${cycle_count} , checking miss backpressure: s0 ready should be blocked")
            dut.io.debug.get.s0_ready.expect(false.B)
            dut.clock.step(1)
            cycle_count += 1
            s2Cycle = 1
            println(s"[INFO] ==================== enter s2 check ====================")
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , only s2 should be valid")
            dut.io.debug.get.s0_valid.expect(false.B)
            dut.io.debug.get.s1_valid.expect(false.B)
            dut.io.debug.get.s2_valid.expect(true.B)
            dut.io.debug.get.s2_vaddr.expect(lineBase.U)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , checking request pulse and wait state")
            dut.io.next_level_req.req.expect(true.B)
            dut.io.debug.get.s2_req_pulse_done.expect(false.B)
            dut.io.debug.get.wait_rsp.expect(false.B)
            dut.clock.step(1)
            cycle_count += 1
            s2Cycle += 1
            println(s"[INFO] ==================== enter post-s2 pulse check ====================")
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , req should be invalid, wait_rsp high, pulse_done high")
            dut.io.next_level_req.req.expect(false.B)
            dut.io.debug.get.s2_req_pulse_done.expect(true.B)
            dut.io.debug.get.wait_rsp.expect(true.B)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , waiting one empty cycle before manual refill response")
            dut.io.next_level_rsp.vld.expect(false.B)
            dut.io.debug.get.s1_valid.expect(false.B)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , before sending 0x4 later, s1_valid = ${dut.io.debug.get.s1_valid.peek().litToBoolean}")
            dut.clock.step(1)
            cycle_count += 1
            s2Cycle += 1
            println(s"[INFO] ==================== enter refill response check ====================")
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , manually return one whole 32B cache line from next level")
            dut.io.next_level_rsp.vld.poke(true.B)
            dut.io.next_level_rsp.data.poke(refillLine.U)
            println(s"[INFO] refill line = 0x${refillLine.toString(16)}")
            dut.io.debug.get.wait_rsp.expect(true.B)
            val dataArrayWe = dut.io.debug.get.data_array_we.peek().litValue
            val tagArrayWe = dut.io.debug.get.tag_array_we.peek().litValue
            assert(dataArrayWe != 0, "debug.data_array_we should not be all zero when refill response is valid")
            assert(tagArrayWe != 0, "debug.tag_array_we should not be all zero when refill response is valid")
            println(s"[INFO] cycle ${cycle_count} , data_array_we = 0x${dataArrayWe.toString(16)}")
            println(s"[INFO] cycle ${cycle_count} , tag_array_we = 0x${tagArrayWe.toString(16)}")
            val dataArrayWeIdx = (0 until cfg.ICACHE_WAY_NUM).filter(i => ((dataArrayWe >> i) & 1) == 1)
            val tagArrayWeIdx = (0 until cfg.ICACHE_WAY_NUM).filter(i => ((tagArrayWe >> i) & 1) == 1)
            println(s"[INFO] cycle ${cycle_count} , data_array_we active ways = ${dataArrayWeIdx.mkString(",")}")
            println(s"[INFO] cycle ${cycle_count} , tag_array_we active ways = ${tagArrayWeIdx.mkString(",")}")
            dut.clock.step(1)
            cycle_count += 1
            s2Cycle += 1
            println(s"[INFO] ==================== enter refill done check ====================")
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , drive next_level_rsp.vld low after one full cycle response")
            dut.io.next_level_rsp.vld.poke(false.B)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , refill_done and s2_done should be high after one-cycle response")
            dut.io.debug.get.wait_rsp.expect(false.B)
            dut.io.debug.get.s2_refill_done.expect(true.B)
            dut.io.debug.get.s2_done.expect(true.B)
            dut.io.debug.get.s2_req_pulse_done.expect(true.B)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , send a new request 0x4 while s2_done is high")
            dut.io.dreq.valid.poke(true.B)
            dut.io.dreq.bits.vaddr.poke((lineBase + 4).U)
            dut.io.dreq.bits.paddr.poke((lineBase + 4).U)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , check 0x4 enters cache while miss result is returned")
            dut.io.debug.get.s0_valid.expect(true.B)
            dut.io.debug.get.s1_valid.expect(false.B)
            dut.io.debug.get.s2_valid.expect(true.B)
            println(s"[INFO] cycle ${cycle_count} , s2 cycle ${s2Cycle} , drsp should respond")
            dut.io.drsp.valid.expect(false.B) // selected refill is captured at this edge
            dut.clock.step(1)
            cycle_count += 1
            println(s"[INFO] ==================== enter post-refill hit pipeline check ====================")
            println(s"[INFO] cycle ${cycle_count} , send next request 0x8 and check hit pipeline state")
            dut.io.dreq.valid.poke(true.B)
            dut.io.dreq.bits.vaddr.poke((lineBase + 8).U)
            dut.io.dreq.bits.paddr.poke((lineBase + 8).U)
            val s1Meta = dut.io.debug.get.s1_meta.peek().litValue
            val s1ValidVec = s1Meta & 0xf
            val s1Plru = (s1Meta >> 4) & 0x7
            println(s"[INFO] cycle ${cycle_count} , cycle 6 state before expect: dreq.ready=${dut.io.dreq.ready.peek().litToBoolean}, s0_valid=${dut.io.debug.get.s0_valid.peek().litToBoolean}, s1_valid=${dut.io.debug.get.s1_valid.peek().litToBoolean}, s1_vaddr=0x${dut.io.debug.get.s1_vaddr.peek().litValue.toString(16)}, s1_tag_hit=0x${dut.io.debug.get.s1_tag_hit.peek().litValue.toString(16)}, s1_hit=${dut.io.debug.get.s1_hit.peek().litToBoolean}, s2_valid=${dut.io.debug.get.s2_valid.peek().litToBoolean}, s2_done=${dut.io.debug.get.s2_done.peek().litToBoolean}")
            println(s"[INFO] cycle ${cycle_count} , cycle 6 meta state: s1_meta=0x${s1Meta.toString(16)}, valid_vec=0x${s1ValidVec.toString(16)}, plru=0x${s1Plru.toString(16)}")
            dut.io.debug.get.s0_valid.expect(true.B)
            dut.io.debug.get.s1_valid.expect(true.B)
            dut.io.debug.get.s2_valid.expect(false.B)
            dut.io.drsp.valid.expect(true.B)
            dut.io.drsp.bits.data.expect("h03020100".U)
            dut.io.dreq.valid.poke(false.B); dut.clock.step()
            dut.io.drsp.valid.expect(true.B); dut.io.drsp.bits.data.expect("h07060504".U)
        }
    }

    "L1ICache should follow default flow after reset" in {
        simulate(new L1ICache(cfg, enabledebug = true)){dut =>
            dut.io.flush.poke(false.B)
            dut.io.dreq.valid.poke(false.B)
            dut.io.dreq.bits.vaddr.poke(0.U)
            dut.io.dreq.bits.paddr.poke(0.U)
            dut.io.drsp.ready.poke(true.B)
            dut.io.next_level_rsp.vld.poke(false.B)
            dut.io.next_level_rsp.data.poke(0.U)

            println("hello world")
        }
    }

    "L1ICache should refill the outstanding miss set when dreq changes under backpressure" in {
        simulate(new L1ICache(cfg, enabledebug = true)) { dut =>
            val missedAddr = BigInt(0x10000320L)
            val redirectedAddr = BigInt(0x100002c0L)
            val refillLine = BigInt("1f1e1d1c1b1a191817161514131211100f0e0d0c0b0a09080000000000050913", 16)

            dut.io.flush.poke(false.B)
            dut.io.drsp.ready.poke(true.B)
            dut.io.next_level_rsp.vld.poke(false.B)
            dut.io.next_level_rsp.data.poke(0.U)
            dut.io.next_level_rsp.error.poke(false.B)

            // Launch a miss for 0x320.
            dut.io.dreq.valid.poke(true.B)
            dut.io.dreq.bits.vaddr.poke(missedAddr.U)
            dut.io.dreq.bits.paddr.poke(missedAddr.U)
            dut.io.dreq.ready.expect(true.B)
            dut.clock.step()
            dut.io.debug.get.s1_vaddr.expect(missedAddr.U)
            dut.io.debug.get.s1_hit.expect(false.B)

            // A redirect changes dreq.bits while the miss is blocking s0.  The
            // changed address must not become the SRAM address for the refill.
            dut.io.dreq.valid.poke(false.B)
            dut.io.dreq.bits.vaddr.poke(redirectedAddr.U)
            dut.io.dreq.bits.paddr.poke(redirectedAddr.U)
            dut.clock.step()
            dut.io.next_level_req.req.expect(true.B)
            dut.io.next_level_req.paddr.expect(missedAddr.U)
            dut.clock.step()
            dut.io.debug.get.wait_rsp.expect(true.B)

            dut.io.next_level_rsp.vld.poke(true.B)
            dut.io.next_level_rsp.data.poke(refillLine.U)
            dut.clock.step()
            dut.io.next_level_rsp.vld.poke(false.B)

            // Let the refill response retire and the blocking miss state clear.
            dut.clock.step()
            dut.io.debug.get.s2_done.expect(false.B)

            // The returned line must first be present at the outstanding miss
            // address, including its requested word.
            dut.io.dreq.valid.poke(true.B)
            dut.io.dreq.bits.vaddr.poke(missedAddr.U)
            dut.io.dreq.bits.paddr.poke(missedAddr.U)
            dut.io.dreq.ready.expect(true.B)
            dut.clock.step()
            dut.io.debug.get.s1_vaddr.expect(missedAddr.U)
            dut.io.debug.get.s1_hit.expect(true.B)
            dut.io.drsp.valid.expect(false.B)
            dut.io.dreq.valid.poke(false.B); dut.clock.step()
            dut.io.drsp.valid.expect(true.B)
            dut.io.drsp.bits.data.expect("h00050913".U)

            // 0x2c0 and 0x320 have the same tag but different set indexes.  A
            // hit here would prove that the 0x320 line was written into the
            // redirect target's set.
            dut.io.dreq.bits.vaddr.poke(redirectedAddr.U)
            dut.io.dreq.bits.paddr.poke(redirectedAddr.U)
            dut.io.dreq.ready.expect(true.B)
            dut.clock.step()
            dut.io.debug.get.s1_vaddr.expect(redirectedAddr.U)
            dut.io.debug.get.s1_hit.expect(false.B)
        }
    }

    
    "SOC3e keeps two accepted hit returns stable under backpressure and flush discards both" in {
        simulate(new L1ICache(cfg)) { d =>
            val a = BigInt("10000000",16)
            val line = BigInt("1f1e1d1c1b1a191817161514131211100f0e0d0c0b0a09080706050403020100",16)
            d.io.flush.poke(false.B); d.io.drsp.ready.poke(true.B)
            d.io.dreq.valid.poke(false.B); d.io.dreq.bits.vaddr.poke(a.U); d.io.dreq.bits.paddr.poke(a.U)
            d.io.next_level_rsp.vld.poke(false.B); d.io.next_level_rsp.error.poke(false.B)
            d.io.next_level_rsp.data.poke(0.U)
            d.reset.poke(true.B); d.clock.step(2); d.reset.poke(false.B)
            d.io.dreq.valid.poke(true.B); d.io.dreq.ready.expect(true.B)
            d.clock.step(); d.io.dreq.valid.poke(false.B); d.clock.step(2)
            d.io.next_level_rsp.vld.poke(true.B); d.io.next_level_rsp.data.poke(line.U)
            d.clock.step(); d.io.next_level_rsp.vld.poke(false.B)
            d.io.drsp.valid.expect(false.B); d.clock.step()
            d.io.drsp.valid.expect(true.B); d.io.drsp.bits.data.expect(BigInt("03020100",16).U)
            d.clock.step(); d.io.drsp.ready.poke(false.B)
            for (off <- Seq(4,8)) {
                d.io.dreq.valid.poke(true.B); d.io.dreq.bits.vaddr.poke((a+off).U)
                d.io.dreq.bits.paddr.poke((a+off).U); d.io.dreq.ready.expect(true.B); d.clock.step()
            }
            d.io.dreq.valid.poke(false.B); d.clock.step()
            for (_ <- 0 until 7) {
                d.io.drsp.valid.expect(true.B); d.io.drsp.bits.vaddr.expect((a+4).U)
                d.io.drsp.bits.data.expect(BigInt("07060504",16).U)
                d.io.dreq.ready.expect(false.B); d.clock.step()
            }
            d.io.drsp.ready.poke(true.B); d.clock.step()
            d.io.drsp.valid.expect(true.B); d.io.drsp.bits.vaddr.expect((a+8).U)
            d.io.drsp.bits.data.expect(BigInt("0b0a0908",16).U)
            // Flush coincides with a potential output handshake: cancel it.
            d.io.flush.poke(true.B); d.io.drsp.valid.expect(false.B); d.clock.step()
            d.io.flush.poke(false.B); d.io.drsp.valid.expect(false.B)
            d.clock.step(4); d.io.drsp.valid.expect(false.B); d.io.dreq.ready.expect(true.B)
        }
    }

}
