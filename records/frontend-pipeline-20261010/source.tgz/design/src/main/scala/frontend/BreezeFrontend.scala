package flow.frontend

import chisel3._
import chisel3.util._

import flow.l1i.{L1ICache, L1IParams}
import flow.config.BreezeMemGeometry
import flow.config._
import flow.interface._
import _root_.circt.stage.ChiselStage

class MiniDecode(val vlen: Int = 64) extends Module {
    val io = IO(new Bundle {
        val pc = Input(UInt(vlen.W))
        val inst = Input(UInt(32.W))
        val predType = Output(FrontendPredType())
        val predTaken = Output(Bool())
        val predPc = Output(UInt(vlen.W))
    })

    val isJal = io.inst(6, 0) === "b1101111".U
    val isJalr = io.inst(6, 0) === "b1100111".U && io.inst(14, 12) === 0.U
    val isBranch = io.inst(6, 0) === "b1100011".U
    val jalImm = Cat(
        Fill(vlen - 21, io.inst(31)),
        io.inst(31),
        io.inst(19, 12),
        io.inst(20),
        io.inst(30, 21),
        0.U(1.W)
    )
    val branchImm = Cat(
        Fill(vlen - 13, io.inst(31)),
        io.inst(31),
        io.inst(7),
        io.inst(30, 25),
        io.inst(11, 8),
        0.U(1.W)
    )

    io.predType := FrontendPredType.NONE
    io.predTaken := false.B
    io.predPc := 0.U

    when(isJal) {
        io.predType := FrontendPredType.JAL
        io.predTaken := true.B
        io.predPc := io.pc + jalImm
    }.elsewhen(isBranch) {
        io.predType := FrontendPredType.BR
        io.predPc := io.pc + branchImm
    }.elsewhen(isJalr) {
        io.predType := FrontendPredType.JALR
    }
}

class BreezeFrontendDebugIO(vlen: Int, ghrLength: Int = 0) extends Bundle {
    val s1_pcReg = Output(UInt(vlen.W))
    val s1_valid = Output(Bool())
    val dreq_valid = Output(Bool())
    val dreq_ready = Output(Bool())
    val dreq_fire = Output(Bool())
    val s2_pcReg = Output(UInt(vlen.W))
    val s2_valid = Output(Bool())
    val s2_respValid = Output(Bool())
    val cache_drsp_valid = Output(Bool())
    val cache_drsp_vaddr = Output(UInt(vlen.W))
    val s3_pcReg = Output(UInt(vlen.W))
    val s3_valid = Output(Bool())
    val cache_s0_ready = Output(Bool())
    val cache_s1_valid = Output(Bool())
    val cache_s1_hit = Output(Bool())
    val cache_s2_valid = Output(Bool())
    val cache_s2_done = Output(Bool())
    val ghr = Output(UInt(ghrLength.max(1).W))
    val s1PredTaken = Output(Bool())
    val s1PredPc = Output(UInt(vlen.W))
    val s1PhtIdx = Output(UInt(ghrLength.max(1).W))
    val s3FastRedirectValid = Output(Bool())
    val s3FastRedirectTarget = Output(UInt(vlen.W))
}

/**
  * 使用 L1ICache 的前端骨架。
  * 当前实现前端入口 PC 选择、cache 请求/返回，以及 s3 的快速预测输出。
  * 地址统一按虚拟地址处理。
  */
class BreezeFrontend(val cfg: BreezeFrontendConfig = BreezeFrontendConfig(), val enabledebug: Boolean = false, val useFASE: Boolean = false,
    memGeometry: BreezeMemGeometry = BreezeMemGeometry(l1Sets = 64)) extends Module {
    val io = IO(new Bundle {
        val resetAddr = Input(UInt(cfg.VLEN.W))
        val fasePause = if (useFASE) Some(Input(Bool())) else None
        val flightEvent = if (useFASE) Some(Output(new flow.fase.FlightEvent)) else None
        val beRedirect = Input(new FrontendRedirectIO(cfg.VLEN))
        val btbUpdate = Input(new BreezeBTBUpdateReq(cfg.VLEN))
        val phtUpdate = Input(new BreezePHTUpdateReq(cfg.branchPredCfg.ghrLength.max(1)))
        val ghrUpdate = Input(new BreezeGHRUpdateReq)
        val translateReq = Decoupled(new BreezeTranslationReq(cfg.VLEN))
        val translateRsp = Flipped(Decoupled(new BreezeTranslationResp(cfg.VLEN)))
        val fetchBuffer = new FrontendFetchBufferIO(cfg.VLEN, cfg.branchPredCfg.ghrLength)
        val nextLevelReq = new L1CacheMissReqIO(cfg.cacheCfg.PLEN)
        val nextLevelRsp = new L1CacheMissRespIO(cfg.cacheCfg.ICACHE_LINE_WIDTH)
        val hpm = Output(new BreezeHpmEvents)
        val debug = if (enabledebug) {
            Some(new BreezeFrontendDebugIO(cfg.VLEN, cfg.branchPredCfg.ghrLength))
        } else None
    })

    val cancelFetch = Wire(Bool())
    // The extra cache return boundary permits two accepted word fetches.
    // Keep prediction metadata per request, rather than overwriting S2 before
    // the older word returns. Compressed fetch already has a single owner.
    val contexts = if (!cfg.enableCompressed) Some(withReset(reset.asBool || cancelFetch) {
        Module(new Queue(new Bundle {
            val pc = UInt(cfg.VLEN.W)
            val ghr = UInt(cfg.branchPredCfg.ghrLength.max(1).W)
            val taken = Bool()
            val target = UInt(cfg.VLEN.W)
            val kind = FrontendPredType()
            val phtIdx = UInt(cfg.branchPredCfg.ghrLength.max(1).W)
        }, 2, pipe = true, flow = false))
    }) else None
    val fetchAllowed = !io.fasePause.getOrElse(false.B) && !cancelFetch &&
        contexts.map(_.io.enq.ready).getOrElse(true.B)
    // ===== Module Instances =====
    val icache = Module(new L1ICache(L1IParams(memGeometry), enabledebug = enabledebug, parallelLookup = cfg.enableMmu))
    val realigner = if (cfg.enableCompressed) Some(Module(new BreezeInstrRealigner(cfg.VLEN))) else None
    val decompressor = if (cfg.enableCompressed) Some(Module(new BreezeCompressedDecoder(enableDouble = true))) else None
    val fetchTranslator = if (cfg.enableMmu) Some(Module(new BreezeFetchTranslator(cfg.VLEN, parallelLookup = true))) else None
    if (cfg.enableMmu) {
        icache.io.arrayReq.get <> fetchTranslator.get.io.arrayReq.get
    }
    io.translateReq.valid := false.B
    io.translateReq.bits := 0.U.asTypeOf(new BreezeTranslationReq(cfg.VLEN))
    io.translateRsp.ready := false.B
    io.hpm := icache.io.hpm
    val isGShare = cfg.branchPredCfg.kind == FrontendBranchPredictorKind.GShare

    // ===== GShare Optional State =====
    val miniDecode = if (isGShare) Some(Module(new MiniDecode(cfg.VLEN))) else None
    val ghrReg = if (isGShare) Some(RegInit(0.U(cfg.branchPredCfg.ghrLength.W))) else None
    private val predictorPcShift = if (cfg.enableCompressed) 1 else 2
    val btb = if (isGShare) Some(Module(new BreezeBTB(
        cfg.VLEN, cfg.branchPredCfg.btbEntryNum, predictorPcShift))) else None
    val pht = if (isGShare) Some(Module(new BreezePHT(
        cfg.VLEN, cfg.branchPredCfg.ghrLength, predictorPcShift))) else None

    // ===== S1: Stage State =====
    val s1_validReg = RegInit(true.B)
    val s1_pcReg = Reg(UInt(cfg.VLEN.W))
    val s1_fire = Wire(Bool())
    val s1_predTaken = Wire(Bool())
    val s1_predPc = Wire(UInt(cfg.VLEN.W))
    val s1_predType = Wire(FrontendPredType())
    val s1_phtIdx = Wire(UInt(cfg.branchPredCfg.ghrLength.max(1).W))

    // ===== S2: Stage State =====
    val s2_validReg = if (cfg.enableCompressed) RegInit(false.B) else contexts.get.io.deq.valid
    val s2_pcReg = if (cfg.enableCompressed) Reg(UInt(cfg.VLEN.W)) else contexts.get.io.deq.bits.pc

    // ===== GShare S2 Metadata =====
    val s2_ghrSnapshotReg = if (isGShare) Some(if (cfg.enableCompressed) RegInit(0.U(cfg.branchPredCfg.ghrLength.W)) else contexts.get.io.deq.bits.ghr) else None
    val s2_predTakenReg = if (isGShare) Some(if (cfg.enableCompressed) RegInit(false.B) else contexts.get.io.deq.bits.taken) else None
    val s2_predPcReg = if (isGShare) Some(if (cfg.enableCompressed) RegInit(0.U(cfg.VLEN.W)) else contexts.get.io.deq.bits.target) else None
    val s2_predTypeReg = if (isGShare) Some(if (cfg.enableCompressed) RegInit(FrontendPredType.NONE) else contexts.get.io.deq.bits.kind) else None
    val s2_phtIdxReg = if (isGShare) Some(if (cfg.enableCompressed) RegInit(0.U(cfg.branchPredCfg.ghrLength.W)) else contexts.get.io.deq.bits.phtIdx) else None

    // ===== S3: Stage State =====
    val s3_validReg = RegInit(false.B)
    val s3_pcReg = Reg(UInt(cfg.VLEN.W))
    val s3_instReg = RegInit(0.U(32.W))
    val s3_rawInstReg = RegInit(0.U(32.W))
    val s3_instLenReg = RegInit(4.U(3.W))
    val s3_compressedReg = RegInit(false.B)
    val s3_illegalCompressedReg = RegInit(false.B)
    val s3_accessFaultReg = RegInit(false.B)
    val s3_pageFaultReg = RegInit(false.B)
    val s3_faultSecondParcelReg = RegInit(false.B)

    // ===== GShare S3 Metadata =====
    val s3_ghrSnapshotReg = if (isGShare) Some(RegInit(0.U(cfg.branchPredCfg.ghrLength.W))) else None
    val s3_predTakenReg = if (isGShare) Some(RegInit(false.B)) else None
    val s3_predPcReg = if (isGShare) Some(RegInit(0.U(cfg.VLEN.W))) else None
    val s3_predTypeReg = if (isGShare) Some(RegInit(FrontendPredType.NONE)) else None
    val s3_phtIdxReg = if (isGShare) Some(RegInit(0.U(cfg.branchPredCfg.ghrLength.W))) else None

    // ===== GShare Correction Wires =====
    val s3_fastRedirectValid = Wire(Bool())
    val s3_fastRedirectTarget = Wire(UInt(cfg.VLEN.W))
    val s3_finalPredTaken = Wire(Bool())
    val s3_finalPredPc = Wire(UInt(cfg.VLEN.W))
    val s3_finalPredType = Wire(FrontendPredType())

    s3_fastRedirectValid := false.B
    s3_fastRedirectTarget := 0.U
    s3_finalPredTaken := false.B
    s3_finalPredPc := 0.U
    s3_finalPredType := FrontendPredType.NONE

    // ===== S0: Next PC Generation =====
    val s0_defaultNextPc = Wire(UInt(cfg.VLEN.W))
    val redirectValid = Wire(Bool())
    val redirectTarget = Wire(UInt(cfg.VLEN.W))
    val s0_fallThroughSel = Wire(Bool())
    val s0_nextPc = Wire(UInt(cfg.VLEN.W))
    val s2_respValid = Wire(Bool())
    val fetchRespValid = Wire(Bool())
    val fetchRespPc = Wire(UInt(cfg.VLEN.W))
    val fetchRespRawInst = Wire(UInt(32.W))
    val fetchRespInst = Wire(UInt(32.W))
    val fetchRespInstLen = Wire(UInt(3.W))
    val fetchRespCompressed = Wire(Bool())
    val fetchRespIllegalCompressed = Wire(Bool())
    val fetchRespAccessFault = Wire(Bool())
    val fetchRespPageFault = Wire(Bool())
    val fetchRespFaultSecondParcel = WireDefault(false.B)

    s0_defaultNextPc := Mux(cfg.enableCompressed.B && s2_respValid,
        s2_pcReg + fetchRespInstLen, s1_pcReg + 4.U)
    redirectValid := io.beRedirect.valid || s3_fastRedirectValid
    cancelFetch := redirectValid || io.beRedirect.flush
    redirectTarget := Mux(io.beRedirect.valid, io.beRedirect.target, s3_fastRedirectTarget)
    s0_fallThroughSel := !redirectValid
    s0_nextPc := Mux(
        reset.asBool,
        io.resetAddr,
        Mux1H(Seq(
            redirectValid -> redirectTarget,
            s0_fallThroughSel -> s0_defaultNextPc
        ))
    )

    s1_predTaken := false.B
    s1_predPc := s1_pcReg + 4.U
    s1_predType := FrontendPredType.NONE
    s1_phtIdx := 0.U

    // ===== GShare S1 Prediction =====
    if (isGShare) {
        btb.get.io.lookup.pc := s1_pcReg
        btb.get.io.update := io.btbUpdate

        pht.get.io.predict.valid := s1_fire
        pht.get.io.predict.pc := s1_pcReg
        pht.get.io.predict.ghr := ghrReg.get
        pht.get.io.update := io.phtUpdate

        s1_phtIdx := pht.get.io.resp.idx

        when(btb.get.io.resp.hit) {
            s1_predType := btb.get.io.resp.predType
            switch(btb.get.io.resp.predType) {
                is(FrontendPredType.JAL) {
                    s1_predTaken := true.B
                    s1_predPc := btb.get.io.resp.target
                }
                is(FrontendPredType.JALR) {
                    s1_predTaken := true.B
                    s1_predPc := btb.get.io.resp.target
                }
                is(FrontendPredType.BR) {
                    s1_predTaken := pht.get.io.resp.taken
                    s1_predPc := Mux(pht.get.io.resp.taken, btb.get.io.resp.target, s1_pcReg + 4.U)
                }
            }
        }

        if (!cfg.enableCompressed) s0_defaultNextPc := s1_predPc
    }

    // ===== GShare Update Path =====
    fetchRespValid := false.B
    fetchRespPc := 0.U
    fetchRespRawInst := 0.U
    fetchRespInst := 0.U
    fetchRespInstLen := 4.U
    fetchRespCompressed := false.B
    fetchRespIllegalCompressed := false.B
    fetchRespAccessFault := false.B
    fetchRespPageFault := false.B

    if (cfg.enableCompressed) {
        val r = realigner.get
        val d = decompressor.get
        r.io.redirect := cancelFetch
        r.io.req.valid := s1_validReg && fetchAllowed && io.fetchBuffer.canAccept3 && !s2_validReg
        r.io.req.bits.pc := s1_pcReg
        if (cfg.enableMmu) {
            val t = fetchTranslator.get
            t.io.inReq <> r.io.wordReq
            r.io.wordRsp <> t.io.inRsp
            icache.io.dreq <> t.io.cacheReq
            t.io.cacheRsp <> icache.io.drsp
            io.translateReq <> t.io.translateReq
            t.io.translateRsp <> io.translateRsp
            t.io.kill := cancelFetch
        } else {
            icache.io.dreq.valid := r.io.wordReq.valid
            icache.io.dreq.bits.vaddr := r.io.wordReq.bits.vaddr
            icache.io.dreq.bits.paddr := r.io.wordReq.bits.vaddr
            r.io.wordReq.ready := icache.io.dreq.ready
            r.io.wordRsp <> icache.io.drsp
        }
        r.io.resp.ready := s2_validReg && !cancelFetch
        d.io.in := r.io.resp.bits.rawInst(15, 0)

        s1_fire := r.io.req.fire
        fetchRespValid := r.io.resp.valid
        fetchRespPc := r.io.resp.bits.pc
        fetchRespRawInst := r.io.resp.bits.rawInst
        fetchRespInst := Mux(r.io.resp.bits.isCompressed, d.io.out, r.io.resp.bits.rawInst)
        fetchRespInstLen := r.io.resp.bits.instLen
        fetchRespCompressed := r.io.resp.bits.isCompressed
        fetchRespIllegalCompressed := r.io.resp.bits.isCompressed && d.io.illegal
        fetchRespAccessFault := r.io.resp.bits.accessFault
        fetchRespPageFault := r.io.resp.bits.pageFault
        fetchRespFaultSecondParcel := (r.io.resp.bits.accessFault || r.io.resp.bits.pageFault) &&
            r.io.resp.bits.faultVaddr === (r.io.resp.bits.pc + 2.U)
    } else {
        if (cfg.enableMmu) {
            val t = fetchTranslator.get
            t.io.inReq.valid := s1_validReg && fetchAllowed && io.fetchBuffer.canAccept3
            t.io.inReq.bits.vaddr := s1_pcReg
            t.io.inReq.bits.paddr := 0.U
            t.io.inRsp.ready := s2_validReg
            icache.io.dreq <> t.io.cacheReq
            t.io.cacheRsp <> icache.io.drsp
            io.translateReq <> t.io.translateReq
            t.io.translateRsp <> io.translateRsp
            t.io.kill := cancelFetch
            s1_fire := t.io.inReq.fire
            fetchRespValid := t.io.inRsp.valid
            fetchRespPc := t.io.inRsp.bits.vaddr
            fetchRespRawInst := t.io.inRsp.bits.data
            fetchRespInst := t.io.inRsp.bits.data
            fetchRespAccessFault := t.io.inRsp.bits.accessFault
            fetchRespPageFault := t.io.inRsp.bits.pageFault
        } else {
            icache.io.dreq.valid := s1_validReg && fetchAllowed && io.fetchBuffer.canAccept3
            icache.io.dreq.bits.vaddr := s1_pcReg
            icache.io.dreq.bits.paddr := s1_pcReg
            icache.io.drsp.ready := true.B // drain canceled word owners as well
            s1_fire := icache.io.dreq.fire
            fetchRespValid := icache.io.drsp.valid
            fetchRespPc := icache.io.drsp.bits.vaddr
            fetchRespRawInst := icache.io.drsp.bits.data
            fetchRespInst := icache.io.drsp.bits.data
            fetchRespAccessFault := icache.io.drsp.bits.accessFault
            fetchRespPageFault := icache.io.drsp.bits.pageFault
        }
    }

    if (isGShare) {
        when(reset.asBool) {
            ghrReg.get := 0.U
        }.elsewhen(io.ghrUpdate.valid) {
            ghrReg.get := Cat(ghrReg.get(cfg.branchPredCfg.ghrLength - 2, 0), io.ghrUpdate.taken)
        }
    }

    // ===== S1: Register Update =====
    when(reset.asBool) {
        s1_validReg := true.B
        s1_pcReg := io.resetAddr
    }.elsewhen(redirectValid) {
        s1_pcReg := redirectTarget
    }.elsewhen(cfg.enableCompressed.B && s2_respValid) {
        val sequentialPc = s2_pcReg + fetchRespInstLen
        val predictedPc = if (isGShare) {
            Mux(s2_predTakenReg.get, s2_predPcReg.get, sequentialPc)
        } else sequentialPc
        s1_pcReg := predictedPc
    }.elsewhen(!cfg.enableCompressed.B && s1_fire) {
        s1_pcReg := s0_nextPc
    }

    if (useFASE) {
        val ev = io.flightEvent.get
        val advance = (cfg.enableCompressed.B && s2_respValid) ||
            (!cfg.enableCompressed.B && s1_fire)
        val seqPc = s2_pcReg + fetchRespInstLen
        val compressedPc = if (isGShare) Mux(s2_predTakenReg.get, s2_predPcReg.get, seqPc) else seqPc
        val adoptedPc = Mux(redirectValid, redirectTarget,
            Mux(cfg.enableCompressed.B && s2_respValid, compressedPc, s0_nextPc))
        ev.valid := redirectValid || advance
        ev.words := VecInit(Seq(
            Cat(fetchRespPageFault, fetchRespAccessFault, advance, s3_fastRedirectValid, io.beRedirect.valid),
            s1_pcReg, adoptedPc, redirectTarget, io.beRedirect.target, s3_fastRedirectTarget, fetchRespPc))
    }

    // ===== S1: Cache Request =====
    icache.io.flush := io.beRedirect.cacheFlush

    // ===== S2: Cache Request Tracking =====
    // A redirect can cancel the frontend request while an ICache miss is still
    // completing.  Only pair a response with the exact request that created
    // the current s2 context; a late wrong-path refill is simply discarded.
    s2_respValid := s2_validReg && fetchRespValid && (fetchRespPc === s2_pcReg)

    if (!cfg.enableCompressed) {
        val q = contexts.get
        q.io.enq.valid := s1_fire
        q.io.enq.bits.pc := s1_pcReg
        q.io.enq.bits.ghr := ghrReg.getOrElse(0.U)
        q.io.enq.bits.taken := s1_predTaken
        q.io.enq.bits.target := s1_predPc
        q.io.enq.bits.kind := s1_predType
        q.io.enq.bits.phtIdx := s1_phtIdx
        q.io.deq.ready := s2_respValid
        when(!reset.asBool && !cancelFetch) {
            assert(q.io.enq.fire === s1_fire, "[SOC3e] fetch metadata lacks a reserved slot")
        }
    } else {
    when(reset.asBool || cancelFetch) {
        s2_validReg := false.B
        s2_pcReg := 0.U
        if (isGShare) {
            s2_ghrSnapshotReg.get := 0.U
            s2_predTakenReg.get := false.B
            s2_predPcReg.get := 0.U
            s2_predTypeReg.get := FrontendPredType.NONE
            s2_phtIdxReg.get := 0.U
        }
    }.elsewhen(s1_fire) {
        s2_validReg := s1_validReg
        s2_pcReg := s1_pcReg
        if (isGShare) {
            s2_ghrSnapshotReg.get := ghrReg.get
            s2_predTakenReg.get := s1_predTaken
            s2_predPcReg.get := s1_predPc
            s2_predTypeReg.get := s1_predType
            s2_phtIdxReg.get := s1_phtIdx
        }
        //printf(p"S1: Send cache request for PC=0x${Hexadecimal(s1_pcReg)}\n")
    }.elsewhen(s2_respValid) {
        s2_validReg := false.B
        if (isGShare) {
            s2_predTakenReg.get := false.B
            s2_predPcReg.get := 0.U
            s2_predTypeReg.get := FrontendPredType.NONE
            s2_phtIdxReg.get := 0.U
        }
    }

    }

    // ===== S3: Cache Response Registers =====
    // S3 不接受背压：当 S2 的返回有效时就装载；否则本拍拉低 valid。
    // 如果下一拍又有新的返回，S3 会直接被新的返回覆盖。
    s3_validReg := false.B
    s3_accessFaultReg := false.B
    s3_pageFaultReg := false.B
    when(!reset.asBool && !cancelFetch && s2_respValid) {
        s3_validReg := true.B
        s3_pcReg := s2_pcReg
        s3_instReg := fetchRespInst
        s3_rawInstReg := fetchRespRawInst
        s3_instLenReg := fetchRespInstLen
        s3_compressedReg := fetchRespCompressed
        s3_illegalCompressedReg := fetchRespIllegalCompressed
        s3_accessFaultReg := fetchRespAccessFault
        s3_pageFaultReg := fetchRespPageFault
        s3_faultSecondParcelReg := fetchRespFaultSecondParcel
        if (isGShare) {
            s3_ghrSnapshotReg.get := s2_ghrSnapshotReg.get
            s3_predTakenReg.get := s2_predTakenReg.get
            s3_predPcReg.get := s2_predPcReg.get
            s3_predTypeReg.get := s2_predTypeReg.get
            s3_phtIdxReg.get := s2_phtIdxReg.get
        }
    }.elsewhen(reset.asBool || cancelFetch) {
        if (isGShare) {
            s3_ghrSnapshotReg.get := 0.U
            s3_predTakenReg.get := false.B
            s3_predPcReg.get := 0.U
            s3_predTypeReg.get := FrontendPredType.NONE
            s3_phtIdxReg.get := 0.U
        }
    }

    // ===== S3: Fetch Buffer Output =====
    io.fetchBuffer.valid := s3_validReg
    io.fetchBuffer.bits.pc := s3_pcReg
    io.fetchBuffer.bits.inst := s3_instReg
    io.fetchBuffer.bits.rawInst := s3_rawInstReg
    io.fetchBuffer.bits.instLen := s3_instLenReg
    io.fetchBuffer.bits.isCompressed := s3_compressedReg
    io.fetchBuffer.bits.illegalCompressed := s3_illegalCompressedReg
    io.fetchBuffer.bits.instructionAccessFault := s3_accessFaultReg
    io.fetchBuffer.bits.instructionPageFault := s3_pageFaultReg
    io.fetchBuffer.bits.instructionFaultSecondParcel := s3_faultSecondParcelReg

    io.fetchBuffer.bits.pred.predType := s3_finalPredType
    io.fetchBuffer.bits.pred.predTaken := s3_finalPredTaken
    io.fetchBuffer.bits.pred.predPc := s3_finalPredPc
    io.fetchBuffer.bits.pred.phtIdx := 0.U

    // ===== GShare S3 Correction =====
    if(isGShare){
        miniDecode.get.io.pc := s3_pcReg
        miniDecode.get.io.inst := s3_instReg

        s3_finalPredType := s3_predTypeReg.get
        s3_finalPredTaken := s3_predTakenReg.get
        s3_finalPredPc := s3_predPcReg.get

        when(s3_validReg) {
            switch(miniDecode.get.io.predType) {
                is(FrontendPredType.JAL) {
                    s3_finalPredType := FrontendPredType.JAL
                    s3_finalPredTaken := true.B
                    s3_finalPredPc := miniDecode.get.io.predPc
                }
                is(FrontendPredType.BR) {
                    s3_finalPredType := FrontendPredType.BR
                    when(s3_predTakenReg.get) {
                        s3_finalPredPc := miniDecode.get.io.predPc
                    }
                }
                is(FrontendPredType.JALR) {
                    s3_finalPredType := FrontendPredType.JALR
                }
            }
        }

        s3_fastRedirectValid := s3_validReg && (
            (miniDecode.get.io.predType === FrontendPredType.JAL &&
                (!s3_predTakenReg.get || s3_predTypeReg.get =/= FrontendPredType.JAL ||
                    s3_predPcReg.get =/= miniDecode.get.io.predPc)) ||
            (miniDecode.get.io.predType === FrontendPredType.BR &&
                s3_predTakenReg.get &&
                s3_predPcReg.get =/= miniDecode.get.io.predPc)
        )
        s3_fastRedirectTarget := s3_finalPredPc
        io.fetchBuffer.bits.pred.phtIdx := s3_phtIdxReg.get
    }

    // ===== Cache Miss Interface =====
    icache.io.next_level_req <> io.nextLevelReq
    icache.io.next_level_rsp <> io.nextLevelRsp

    io.debug.foreach { debug =>
        debug.s1_pcReg := s1_pcReg
        debug.s1_valid := s1_validReg
        debug.dreq_valid := icache.io.dreq.valid
        debug.dreq_ready := icache.io.dreq.ready
        debug.dreq_fire := s1_fire
        debug.s2_pcReg := s2_pcReg
        debug.s2_valid := s2_validReg
        debug.s2_respValid := s2_respValid
        debug.cache_drsp_valid := icache.io.drsp.valid
        debug.cache_drsp_vaddr := icache.io.drsp.bits.vaddr
        debug.s3_pcReg := s3_pcReg
        debug.s3_valid := s3_validReg
        debug.cache_s0_ready := icache.io.debug.get.s0_ready
        debug.cache_s1_valid := icache.io.debug.get.s1_valid
        debug.cache_s1_hit := icache.io.debug.get.s1_hit
        debug.cache_s2_valid := icache.io.debug.get.s2_valid
        debug.cache_s2_done := icache.io.debug.get.s2_done
        debug.ghr := 0.U
        debug.s1PredTaken := s1_predTaken
        debug.s1PredPc := s1_predPc
        debug.s1PhtIdx := s1_phtIdx
        debug.s3FastRedirectValid := s3_fastRedirectValid
        debug.s3FastRedirectTarget := s3_fastRedirectTarget
        if (isGShare) {
            debug.ghr := ghrReg.get
        }
    }
}

object FireBreezeFrontend extends App {
    ChiselStage.emitSystemVerilogFile(
        new BreezeFrontend(),
        Array("--target-dir", "build"),
        firtoolOpts = Array(
            "-disable-all-randomization",
            "-strip-debug-info",
            "-default-layer-specialization=enable"
        )
    )
}
