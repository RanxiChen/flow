package flow.core

import chisel3._
import chisel3.util._
import flow.config.{BreezePmpConfig, PrivilegeProfile}
import flow.interface._
/**
  * Register File, used to store general purpose registers
  * @param XLEN
  */

class RegFileIO(XLEN:Int) extends Bundle{
    val rs1_addr = Input(UInt(5.W))
    val rs2_addr = Input(UInt(5.W))
    val rd_addr  = Input(UInt(5.W))
    val rd_data  = Input(UInt(XLEN.W))
    val rd_en    = Input(Bool())
    val rs1_data = Output(UInt(XLEN.W))
    val rs2_data = Output(UInt(XLEN.W))
}

class RegFile(XLEN:Int=64,val dumplog:Boolean=false) extends Module {
    val io = IO(new RegFileIO(XLEN))
    // Asynchronous reads and one synchronous write infer FPGA distributed RAM.
    // Reset only the validity bits: resetting every data bit prevents RAM
    // inference. Unwritten registers still read zero, including after reset.
    val content = Mem(32, UInt(XLEN.W))
    val initialized = RegInit(VecInit(Seq.fill(32)(false.B)))
    def stored(addr: UInt): UInt = Mux(initialized(addr), content(addr), 0.U)
    val writeValid = io.rd_en && (io.rd_addr =/= 0.U)
    val rs1WriteHit = writeValid && (io.rs1_addr === io.rd_addr)
    val rs2WriteHit = writeValid && (io.rs2_addr === io.rd_addr)

    // WB writes and decode reads happen in the same cycle. Make that ordering
    // explicit so a consumer sees the value being committed, not the previous
    // contents of the register file.
    io.rs1_data := Mux(io.rs1_addr === 0.U, 0.U,
        Mux(rs1WriteHit, io.rd_data, stored(io.rs1_addr)))
    io.rs2_data := Mux(io.rs2_addr === 0.U, 0.U,
        Mux(rs2WriteHit, io.rd_data, stored(io.rs2_addr)))
    when(writeValid && !reset.asBool){
        content(io.rd_addr) := io.rd_data
        initialized(io.rd_addr) := true.B
    }        
    if(dumplog){
    printf(cf"[RegFile]\n")
    for(i <- 0 until 32){
        printf(cf"x[${i}%02d]=0x${stored(i.U(5.W))}%x    ")
        if(i%4 == 3){
            printf("\n")
        }        
    }
    printf("\n")
    }
}

// Derived from Rocket Chip project (BSD 3-Clause License)
// Modified for this project
import scala.collection.mutable.ArrayBuffer
class RocketRegFile extends Module {
    val io = IO(new RegFileIO(64))
    val n = 31
    val w = 64
    val zero = false
    val rf = Mem(n, UInt(w.W))
  private def access(addr: UInt) = rf(~addr(log2Up(n)-1,0))
  private val reads = ArrayBuffer[(UInt,UInt)]()
  private var canRead = true
  def read(addr: UInt) = {
    require(canRead)
    reads += addr -> Wire(UInt())
    reads.last._2 := Mux(zero.B && addr === 0.U, 0.U, access(addr))
    reads.last._2
  }
  def write(addr: UInt, data: UInt) = {
    canRead = false
    when (addr =/= 0.U) {
      access(addr) := data
      for ((raddr, rdata) <- reads)
        when (addr === raddr) { rdata := data }
    }
  }
    io.rs1_data := read(io.rs1_addr)
    io.rs2_data := read(io.rs2_addr)
    when(io.rd_en){
        write(io.rd_addr, io.rd_data)
    }
}

class DiffRegFile extends Module {
    val io = IO(new Bundle{
        val sucess = Output(Bool())
        val index = Output(UInt(5.W))
        val reg1 = Output(UInt(64.W))
        val reg2 = Output(UInt(64.W))
    })
    io.sucess := false.B
    io.index := 0.U
    io.reg1 := 0.U
    io.reg2 := 0.U
    val a = Module(new RegFile(64))
    val b = Module(new RocketRegFile())
    val cnt = RegInit(0.U(5.W))
    val counter = RegInit(0.U(7.W))
    counter := counter + 1.U
    //first 32 cycle write
    when(counter < 32.U){
        a.io.rd_en := true.B
        b.io.rd_en := true.B
        a.io.rd_addr := counter
        b.io.rd_addr := counter
        a.io.rd_data := counter + 10.U
        b.io.rd_data := counter + 10.U
        a.io.rs1_addr := 0.U
        a.io.rs2_addr := 0.U
        b.io.rs1_addr := 0.U
        b.io.rs2_addr := 0.U
    }.otherwise{
        a.io.rd_en := false.B
        b.io.rd_en := false.B
        val read_addr = counter(4,0)
        a.io.rs1_addr := read_addr
        a.io.rs2_addr := read_addr + 1.U
        b.io.rs1_addr := read_addr
        b.io.rs2_addr := read_addr + 1.U
        a.io.rd_addr := 0.U
        a.io.rd_data := 0.U
        b.io.rd_addr := 0.U
        b.io.rd_data := 0.U
        when(a.io.rs1_data =/= b.io.rs1_data){
            io.sucess := false.B
            io.index := read_addr
            io.reg1 := a.io.rs1_data
            io.reg2 := b.io.rs1_data
        }.elsewhen(a.io.rs2_data =/= b.io.rs2_data){
            io.sucess := false.B
            io.index := read_addr + 1.U
            io.reg1 := a.io.rs2_data
            io.reg2 := b.io.rs2_data
        }.otherwise{
            io.sucess := true.B
            io.index := 0.U
            io.reg1 := 0.U
            io.reg2 := 0.U
        }
    }
}

import _root_.circt.stage.ChiselStage

object GenerateRegFileVerilogFile extends App {
    ChiselStage.emitSystemVerilogFile(
        new DiffRegFile(),
        Array("--target-dir", "build"),
        firtoolOpts = Array("-disable-all-randomization", "-strip-debug-info", "-default-layer-specialization=enable")
    )
}

class CSRFile(XLEN:Int=64,val dumplog:Boolean=false, val enabledebug:Boolean=false,
              val hartId:Int=0,
              val privilegeProfile: PrivilegeProfile = PrivilegeProfile.Mcu,
              val enableCompressed: Boolean = false, val useFASE: Boolean = false) extends Module {
    require(hartId >= 0, "CSRFile hartId must be non-negative")
    val io = IO(new Bundle{
        val faseEnter = if (useFASE) Some(Input(Bool())) else None
        val faseDiagnostic = if (useFASE) Some(Output(Vec(12, UInt(XLEN.W)))) else None
        val csr_addr = Input(UInt(12.W))
        val csr_cmd  = Input(UInt(CSR_CMD.width.W))
        val csr_reg_data = Input(UInt(XLEN.W))
        val csr_old_data = Output(UInt(XLEN.W))
        val csr_new_data = Output(UInt(XLEN.W))
        val csr_write_en = Output(Bool())
        val rs1_id = Input(UInt(5.W))
        val rd_id = Input(UInt(5.W))
        val commit_valid = Input(Bool())
        val commit_addr = Input(UInt(12.W))
        val commit_wdata = Input(UInt(XLEN.W))
        val commit_write_en = Input(Bool())
        // Floating-point architectural state is updated only at the common
        // WB commit point. fp_flags are ordered NV,DZ,OF,UF,NX.
        val fp_commit_valid = Input(Bool())
        val fp_flags = Input(UInt(5.W))
        val frm = Output(UInt(3.W))
        val fp_enabled = Output(Bool())
        val retire_valid = Input(Bool())
        val hpmEvents = Input(new BreezeHpmEvents)
        val machineTimerInterrupt = Input(Bool())
        val machineSoftwareInterrupt = Input(Bool())
        val machineExternalInterrupt = Input(Bool())
        val supervisorExternalInterrupt = Input(Bool())
        val time = Input(UInt(XLEN.W))
        val trap = Input(new CSRTrapInfo(XLEN))
        val mret_commit = Input(Bool())
        val sret_commit = Input(Bool())
        val mtvec = Output(UInt(XLEN.W))
        val mepc_out = Output(UInt(XLEN.W))
        val trap_target = Output(UInt(XLEN.W))
        val xret_target = Output(UInt(XLEN.W))
        val current_privilege = Output(UInt(PRIV_MODE.width.W))
        val mret_illegal = Output(Bool())
        val sret_illegal = Output(Bool())
        val wfi_illegal = Output(Bool())
        val sfence_vma_illegal = Output(Bool())
        val mmu_context = Output(new BreezeMmuContext(XLEN))
        // WFI wakeup is intentionally distinct from interruptPending.  The
        // privileged architecture requires a locally enabled pending
        // interrupt to resume WFI regardless of mstatus.MIE/SIE or mideleg.
        val wfiWakeup = Output(Bool())
        val interruptPending = Output(Bool())
        val interruptCause = Output(UInt(XLEN.W))
        val csr_illegal = Output(Bool())
        val debug = if (enabledebug) Some(new CSRFDebugIO(XLEN)) else None
    })
    // csr supported
    val printer = RegInit(0.U(XLEN.W))
    private val implementedHpmCounters = 8
    val performance = Module(new BreezePerformanceCounters(XLEN, implementedHpmCounters))
    performance.io.write := io.commit_valid && io.commit_write_en && !io.trap.valid
    performance.io.address := io.commit_addr
    performance.io.data := io.commit_wdata
    performance.io.retire := io.retire_valid
    performance.io.events := io.hpmEvents
    val coreinst = performance.io.coreinst
    val mcycle = performance.io.mcycle
    val minstret = performance.io.minstret
    val mhpmcounter = performance.io.counter
    val mhpmevent = performance.io.selector
    val mcountinhibit = performance.io.inhibit
    val menvcfg = RegInit(0.U(XLEN.W))
    private val enableSupervisorUser = privilegeProfile.enableSupervisorUser
    val misa_value = (BigInt(2) << 62) | (BigInt(1) << 12) | (BigInt(1) << 8) |
        (BigInt(1) << 5) | (BigInt(1) << 3) | BigInt(1) |
        (if (enableCompressed) BigInt(1) << 2 else BigInt(0)) |
        (if (enableSupervisorUser) (BigInt(1) << 18) | (BigInt(1) << 20) else BigInt(0))
    val misa = WireDefault(misa_value.U(XLEN.W))
    val mvendorid = RegInit(0.U(32.W))
    val marchid = RegInit(0.U(XLEN.W))
    val mimpid = RegInit(0.U(XLEN.W))
    val mhartid = RegInit(hartId.U(XLEN.W)) // per-hart elaboration identity (Tile hartId)
    val mepc = RegInit(0.U(XLEN.W))
    val mtvec = RegInit(BigInt("200", 16).U(XLEN.W))
    val mcause = RegInit(0.U(XLEN.W))
    val mtval = RegInit(0.U(XLEN.W))
    val mscratch = RegInit(0.U(XLEN.W))
    val medeleg = RegInit(0.U(XLEN.W))
    val mideleg = RegInit(0.U(XLEN.W))
    val stvec = RegInit(0.U(XLEN.W))
    val sepc = RegInit(0.U(XLEN.W))
    val scause = RegInit(0.U(XLEN.W))
    val stval = RegInit(0.U(XLEN.W))
    val sscratch = RegInit(0.U(XLEN.W))
    val satp = RegInit(0.U(XLEN.W))
    val pmpcfg = RegInit(VecInit(Seq.fill(BreezePmpConfig.ActiveEntries)(0.U(8.W))))
    val pmpaddr = RegInit(VecInit(Seq.fill(BreezePmpConfig.ActiveEntries)(0.U(54.W))))
    // Candidate state depends only on the WB CSR payload and stored locks.
    // Keep the late commit/trap permission out of the wide range decoder;
    // it gates the architectural and decoded registers together below.
    val candidatePmpCfg = WireDefault(pmpcfg)
    val candidatePmpAddr = WireDefault(pmpaddr)
    val pmpCfgAddress = io.commit_addr === CSRMAP.pmpcfg0.U ||
        io.commit_addr === CSRMAP.pmpcfg2.U
    val pmpCfgBank = Mux(io.commit_addr === CSRMAP.pmpcfg0.U, 0.U, 8.U)
    for (index <- 0 until BreezePmpConfig.ActiveEntries) {
        val lane = index & 7
        val requested = io.commit_wdata(8 * lane + 7, 8 * lane)
        val legal = Cat(requested(7), 0.U(2.W), requested(4, 3),
            requested(2), Mux(requested(0), requested(1), false.B), requested(0))
        when(pmpCfgAddress && pmpCfgBank === (index & 8).U && !pmpcfg(index)(7)) {
            candidatePmpCfg(index) := legal
        }
        val ownLocked = pmpcfg(index)(7)
        val nextTorLocked = if (index == BreezePmpConfig.ActiveEntries - 1) false.B else
            pmpcfg(index + 1)(7) && pmpcfg(index + 1)(4, 3) === 1.U
        when(io.commit_addr === (CSRMAP.pmpaddr0 + index).U &&
            !ownLocked && !nextTorLocked) {
            candidatePmpAddr(index) := io.commit_wdata(53, 0)
        }
    }
    // TOR also observes the candidate predecessor, so both bounds become
    // visible on the same edge as the corresponding raw CSR write.
    val candidatePmpRanges = VecInit((0 until BreezePmpConfig.ActiveEntries).map { index =>
        flow.mmu.BreezePmpDecode.range(candidatePmpCfg(index), candidatePmpAddr(index),
            if (index == 0) 0.U(54.W) else candidatePmpAddr(index - 1))
    })
    val pmpRanges = RegInit(VecInit(Seq.fill(BreezePmpConfig.ActiveEntries)(
        flow.mmu.BreezePmpDecode.range(0.U(8.W), 0.U(54.W), 0.U(54.W)))))
    // Keep all 16 CSR slots visible to firmware probing. Entries 8..15 have
    // no storage, ignore writes, and read as zero through both interfaces.
    val visiblePmpCfg = VecInit((0 until BreezePmpConfig.CsrEntries).map { index =>
        if (index < BreezePmpConfig.ActiveEntries) pmpcfg(index) else 0.U(8.W)
    })
    val visiblePmpAddr = VecInit((0 until BreezePmpConfig.CsrEntries).map { index =>
        if (index < BreezePmpConfig.ActiveEntries) pmpaddr(index) else 0.U(54.W)
    })
    val scounteren = RegInit(0.U(32.W))
    val stimecmp = RegInit(Fill(XLEN, 1.U(1.W)))
    val mcounteren = RegInit(0.U(32.W))
    val currentPrivilege = RegInit(PRIV_MODE.M.U(PRIV_MODE.width.W))
    // mstatus: distributed fields, assembled on read, disassembled on write
    val mstatus_MIE  = RegInit(false.B)      // bit 3:  machine interrupt enable
    val mstatus_MPIE = RegInit(false.B)      // bit 7:  machine previous interrupt enable
    val mstatus_MPP  = RegInit(PRIV_MODE.M.U(2.W))
    val mstatus_SIE  = RegInit(false.B)
    val mstatus_SPIE = RegInit(false.B)
    val mstatus_SPP  = RegInit(false.B)
    val mstatus_FS   = RegInit(0.U(2.W))     // bits 14-13: Off/Initial/Clean/Dirty
    val mstatus_TVM  = RegInit(false.B)      // bit 20: trap S-mode satp/SFENCE.VMA
    val mstatus_TW   = RegInit(false.B)      // bit 21: trap S-mode WFI
    val mstatus_TSR  = RegInit(false.B)      // bit 22: trap S-mode SRET
    val mstatus_MPRV = RegInit(false.B)
    val mstatus_SUM  = RegInit(false.B)
    val mstatus_MXR  = RegInit(false.B)
    val fflags = RegInit(0.U(5.W))
    val frm = RegInit(0.U(3.W))
    val mie_MSIE = RegInit(false.B)          // bit 3:  machine software interrupt enable
    val mie_MTIE = RegInit(false.B)          // bit 7:  machine timer interrupt enable
    val mie_MEIE = RegInit(false.B)          // bit 11: machine external interrupt enable
    val mie_SSIE = RegInit(false.B)
    val mie_STIE = RegInit(false.B)
    val mie_SEIE = RegInit(false.B)
    val sip_SSIP = RegInit(false.B)
    // Without STCE, OpenSBI forwards CLINT timer interrupts by writing mip.STIP.
    val mip_STIP = RegInit(false.B)
    val mip_SEIP = RegInit(false.B)
    val mstatus_read = Wire(UInt(XLEN.W))
    val linuxXlenFields = if (enableSupervisorUser) {
        ((BigInt(2) << 34) | (BigInt(2) << 32)).U(XLEN.W)
    } else 0.U(XLEN.W)
    mstatus_read := ((mstatus_FS === "b11".U).asUInt << (XLEN - 1)) |
        linuxXlenFields | (mstatus_TSR.asUInt << 22) | (mstatus_TW.asUInt << 21) |
        (mstatus_TVM.asUInt << 20) | (mstatus_MXR.asUInt << 19) |
        (mstatus_SUM.asUInt << 18) | (mstatus_MPRV.asUInt << 17) |
        (mstatus_FS << 13) | (mstatus_MPP << 11) |
        (mstatus_SPP.asUInt << 8) | (mstatus_MPIE.asUInt << 7) |
        (mstatus_SPIE.asUInt << 5) | (mstatus_MIE.asUInt << 3) |
        (mstatus_SIE.asUInt << 1)
    val sstatus_read = Wire(UInt(XLEN.W))
    sstatus_read := ((mstatus_FS === "b11".U).asUInt << (XLEN - 1)) |
        (if (enableSupervisorUser) (BigInt(2) << 32).U(XLEN.W) else 0.U(XLEN.W)) |
        (mstatus_MXR.asUInt << 19) | (mstatus_SUM.asUInt << 18) |
        (mstatus_FS << 13) | (mstatus_SPP.asUInt << 8) |
        (mstatus_SPIE.asUInt << 5) | (mstatus_SIE.asUInt << 1)
    val mie_read = Wire(UInt(XLEN.W))
    val mip_read = Wire(UInt(XLEN.W))
    // Independent small compares followed by a balanced lexicographic tree.
    // Preserve combinational time/stimecmp visibility (no pending register).
    val timerChunks = (0 until (XLEN + 7) / 8).reverse.map { chunk =>
        val hi = math.min(XLEN - 1, chunk * 8 + 7)
        val t = io.time(hi, chunk * 8)
        val c = stimecmp(hi, chunk * 8)
        (t > c, t === c)
    }
    def compareTimer(parts: Seq[(Bool, Bool)]): (Bool, Bool) = {
        if (parts.size == 1) parts.head else {
            val (highGt, highEq) = compareTimer(parts.take(parts.size / 2))
            val (lowGt, lowEq) = compareTimer(parts.drop(parts.size / 2))
            (highGt || (highEq && lowGt), highEq && lowEq)
        }
    }
    val (timerGt, timerEq) = compareTimer(timerChunks)
    val supervisorTimerPending = timerGt || timerEq
    mie_read := (mie_MEIE.asUInt << MACHINE_INTERRUPT_CAUSE.EXTERNAL) |
        (mie_MTIE.asUInt << MACHINE_INTERRUPT_CAUSE.TIMER) |
        (mie_MSIE.asUInt << MACHINE_INTERRUPT_CAUSE.SOFTWARE) |
        (mie_SEIE.asUInt << SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL) |
        (mie_STIE.asUInt << SUPERVISOR_INTERRUPT_CAUSE.TIMER) |
        (mie_SSIE.asUInt << SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
    mip_read := (io.machineExternalInterrupt.asUInt << MACHINE_INTERRUPT_CAUSE.EXTERNAL) |
        (io.machineTimerInterrupt.asUInt << MACHINE_INTERRUPT_CAUSE.TIMER) |
        (io.machineSoftwareInterrupt.asUInt << MACHINE_INTERRUPT_CAUSE.SOFTWARE) |
        ((enableSupervisorUser.B && (mip_SEIP || io.supervisorExternalInterrupt)).asUInt << SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL) |
        (Mux(menvcfg(63), supervisorTimerPending, mip_STIP).asUInt << SUPERVISOR_INTERRUPT_CAUSE.TIMER) |
        (sip_SSIP.asUInt << SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
    val sie_read = mie_read & mideleg
    val sip_read = mip_read & mideleg
    io.wfiWakeup := (mie_read & mip_read).orR
    // Each entry names one physical value and all of its CSR read aliases.
    // One shared address decode drives both the whitelist and the read mux.
    def entry(data: UInt, addresses: Int*): (Seq[Int], UInt) = (addresses.toSeq, data)
    val statusReads = Seq(
        entry(mepc, CSRMAP.mepc), entry(mtvec, CSRMAP.mtvec),
        entry(mcause, CSRMAP.mcause), entry(mtval, CSRMAP.mtval),
        entry(mscratch, CSRMAP.mscratch), entry(mstatus_read, CSRMAP.mstatus),
        entry(mie_read, CSRMAP.mie), entry(mip_read, CSRMAP.mip),
        entry(mcounteren, CSRMAP.mcounteren), entry(menvcfg, CSRMAP.menvcfg)
    ) ++ (if (enableSupervisorUser) Seq(
        entry(medeleg, CSRMAP.medeleg), entry(mideleg, CSRMAP.mideleg),
        entry(sstatus_read, CSRMAP.sstatus), entry(sie_read, CSRMAP.sie),
        entry(stvec, CSRMAP.stvec), entry(scounteren, CSRMAP.scounteren),
        entry(sscratch, CSRMAP.sscratch), entry(sepc, CSRMAP.sepc),
        entry(scause, CSRMAP.scause), entry(stval, CSRMAP.stval),
        entry(sip_read, CSRMAP.sip), entry(stimecmp, CSRMAP.stimecmp)
    ) else Seq.empty)
    val protectionReads = Seq(
        entry(Cat(visiblePmpCfg.slice(0, 8).reverse), CSRMAP.pmpcfg0),
        entry(Cat(visiblePmpCfg.slice(8, 16).reverse), CSRMAP.pmpcfg2)
    ) ++ (0 until BreezePmpConfig.CsrEntries).map(index =>
        entry(visiblePmpAddr(index), CSRMAP.pmpaddr0 + index)) ++
        (if (enableSupervisorUser) Seq(entry(satp, CSRMAP.satp)) else Seq.empty)
    val performanceReads = Seq(
        entry(coreinst, CSRMAP.coreinst),
        entry(mcycle, CSRMAP.mcycle, CSRMAP.cycle),
        entry(minstret, CSRMAP.minstret, CSRMAP.instret),
        entry(io.time, CSRMAP.time), entry(mcountinhibit, CSRMAP.mcountinhibit)
    ) ++ (0 until implementedHpmCounters).flatMap(index => Seq(
        entry(mhpmcounter(index), CSRMAP.mhpmcounter3 + index, CSRMAP.hpmcounter3 + index),
        entry(mhpmevent(index), CSRMAP.mhpmevent3 + index)))
    val otherReads = Seq(
        entry(fflags, CSRMAP.fflags), entry(frm, CSRMAP.frm),
        entry(Cat(frm, fflags), CSRMAP.fcsr), entry(printer, CSRMAP.printer),
        entry(misa, CSRMAP.misa), entry(mvendorid, CSRMAP.mvendorid),
        entry(marchid, CSRMAP.marchid), entry(mimpid, CSRMAP.mimpid),
        entry(mhartid, CSRMAP.mhartid),
        // No triggers: tselect/tdata1/tdata2 read zero and ignore writes, so
        // tdata1.type == 0 tells probing software that no trigger exists.
        entry(0.U, CSRMAP.tselect, CSRMAP.tdata1, CSRMAP.tdata2)
    )
    val readBanks = Seq(statusReads, protectionReads, performanceReads, otherReads)
    val implementedAddresses = readBanks.flatten.flatMap(_._1)
    require(implementedAddresses.distinct.size == implementedAddresses.size,
        "CSR read addresses must be unique for parallel selection")
    val addressHits = implementedAddresses.map(address =>
        address -> (io.csr_addr === address.U(12.W))).toMap
    val bankData = readBanks.map(bank => Mux1H(bank.map { case (addresses, data) =>
        addresses.map(addressHits(_)).reduce(_ || _) -> data.pad(XLEN)
    }))
    val csrImplemented = addressHits.values.toSeq.reduce(_ || _)
    val old_csr_val = WireDefault(0.U(XLEN.W))
    val new_csr_val = WireDefault(old_csr_val)
    val read_csr = WireDefault(false.B)
    val write_csr = WireDefault(false.B)
    val uimm = io.csr_reg_data(4, 0)
    // Unselected banks produce zero. All selectors are mutually exclusive;
    // no priority chain is required within or between banks.
    old_csr_val := Mux(read_csr, bankData.reduce(_ | _), 0.U)
    val fpCsrAccess = addressHits(CSRMAP.fflags) ||
        addressHits(CSRMAP.frm) || addressHits(CSRMAP.fcsr)
    val csrAccess = io.csr_cmd =/= CSR_CMD.NOP.U
    val privilegeDenied = currentPrivilege < io.csr_addr(9, 8)
    // These simulation-only CSRs live in a non-standard U-privilege address
    // range, but remain machine-only in the Linux profile.
    val customCsrDenied = currentPrivilege =/= PRIV_MODE.M.U &&
        (io.csr_addr === CSRMAP.printer.U || io.csr_addr === CSRMAP.coreinst.U)
    val satpDenied = currentPrivilege === PRIV_MODE.S.U && mstatus_TVM &&
        io.csr_addr === CSRMAP.satp.U
    val sstcDenied = io.csr_addr === CSRMAP.stimecmp.U &&
        currentPrivilege =/= PRIV_MODE.M.U && (!menvcfg(63) || !mcounteren(1))
    val readOnlyWrite = io.csr_addr(11, 10) === 3.U && write_csr
    val counterIndex = MuxLookup(io.csr_addr, 0.U(5.W))(Seq(
        CSRMAP.cycle.U -> 0.U,
        CSRMAP.time.U -> 1.U,
        CSRMAP.instret.U -> 2.U
    ) ++ (0 until implementedHpmCounters).map(index =>
        (CSRMAP.hpmcounter3 + index).U -> (index + 3).U))
    val userCounterAccess = io.csr_addr === CSRMAP.cycle.U || io.csr_addr === CSRMAP.time.U ||
        io.csr_addr === CSRMAP.instret.U ||
        (io.csr_addr >= CSRMAP.hpmcounter3.U &&
          io.csr_addr < (CSRMAP.hpmcounter3 + implementedHpmCounters).U)
    val counterDenied = userCounterAccess && Mux(
        currentPrivilege === PRIV_MODE.S.U,
        !mcounteren(counterIndex),
        Mux(currentPrivilege === PRIV_MODE.U.U,
            !mcounteren(counterIndex) || !scounteren(counterIndex), false.B))
    // CSR support is whitelist-based in every privilege profile. Unknown CSR
    // addresses must raise an illegal-instruction exception; returning zero
    // would make probing firmware falsely advertise extensions that are not
    // implemented by the core.
    io.csr_illegal := csrAccess && (
        !csrImplemented || privilegeDenied || customCsrDenied || satpDenied || sstcDenied ||
        readOnlyWrite || counterDenied ||
        (fpCsrAccess && mstatus_FS === 0.U))

    // SEIP reads include the external wire, but CSR read/modify/write uses
    // only its software-pending bit (Privileged ISA, machine interrupt CSRs).
    val seipMask = (BigInt(1) << SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL).U(XLEN.W)
    val csrModifyValue = Mux(io.csr_addr === CSRMAP.mip.U,
        (old_csr_val & ~seipMask) | (mip_SEIP.asUInt << SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL),
        old_csr_val)
    when(!io.trap.valid){
        switch(io.csr_cmd){
            is(CSR_CMD.NOP.U){
            //nop
            read_csr := false.B
            write_csr := false.B
        }
        is(CSR_CMD.RW.U){
            read_csr := Mux(io.rd_id =/= 0.U, true.B, false.B)
            write_csr := true.B
            new_csr_val := io.csr_reg_data
            //printf(cf"[CSR] rw = 0x${io.csr_reg_data}%x\n")
        }
        is(CSR_CMD.RS.U){
            read_csr := true.B
            write_csr := Mux(io.rs1_id =/= 0.U, true.B, false.B)
            new_csr_val := csrModifyValue | io.csr_reg_data
        }
        is(CSR_CMD.RC.U){
            read_csr := true.B
            write_csr := Mux(io.rs1_id =/= 0.U, true.B, false.B)
            new_csr_val := csrModifyValue & (~io.csr_reg_data)
        }
        is(CSR_CMD.RWI.U){
           read_csr := Mux(io.rd_id =/= 0.U, true.B, false.B)
           write_csr := true.B
           new_csr_val := io.csr_reg_data 
        }
        is(CSR_CMD.RSI.U){
            read_csr := true.B
            write_csr := Mux(uimm =/= 0.U, true.B, false.B)
            new_csr_val := csrModifyValue | io.csr_reg_data
        }
        is(CSR_CMD.RCI.U){
            read_csr := true.B
            write_csr := Mux(uimm =/= 0.U, true.B, false.B)
            new_csr_val := csrModifyValue & (~io.csr_reg_data)
        }
    }
    }
    // FP arithmetic flags are sticky. A killed instruction never asserts
    // fp_commit_valid, so speculative FPnew responses cannot alter CSR state.
    when(io.fp_commit_valid) {
        fflags := fflags | io.fp_flags
        mstatus_FS := "b11".U
    }

    // Zicsr对寄存器的写在wb阶段提交
    val medelegMask = Seq(1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 15)
        .map(bit => BigInt(1) << bit).reduce(_ | _).U(XLEN.W)
    val midelegMask = Seq(
        SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE,
        SUPERVISOR_INTERRUPT_CAUSE.TIMER,
        SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL)
        .map(bit => BigInt(1) << bit).reduce(_ | _).U(XLEN.W)
    when(io.commit_valid && io.commit_write_en && !io.trap.valid){
        switch(io.commit_addr){
            is(CSRMAP.fflags.U) {
                fflags := io.commit_wdata(4, 0)
                mstatus_FS := "b11".U
            }
            is(CSRMAP.frm.U) {
                frm := Mux(io.commit_wdata(2, 0) <= 4.U, io.commit_wdata(2, 0), 0.U)
                mstatus_FS := "b11".U
            }
            is(CSRMAP.fcsr.U) {
                fflags := io.commit_wdata(4, 0)
                frm := Mux(io.commit_wdata(7, 5) <= 4.U, io.commit_wdata(7, 5), 0.U)
                mstatus_FS := "b11".U
            }
            is(CSRMAP.printer.U){
                printer := io.commit_wdata
                if(dumplog){
                    printf(cf"[INFO] printer = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.coreinst.U){
                if(dumplog){
                    printf(cf"[INFO] coreinst = 0x${coreinst}%x\n")
                }
            }
            is(CSRMAP.misa.U){
                //currently misa is read only
                if(dumplog){
                    printf(cf"[INFO] misa = 0x${misa}%x\n")
                }
            }
            is(CSRMAP.mvendorid.U, CSRMAP.marchid.U, CSRMAP.mimpid.U){
                //currently mvendorid is read only
                if(dumplog){
                    printf(cf"[INFO] unimplemented csr\n")
                }
            }
            is(CSRMAP.mhartid.U){
                //currently mhartid is read only
                if(dumplog){
                    printf(cf"[INFO] mhartid = ${mhartid}%x\n")
                }
            }
            is(CSRMAP.mtvec.U){
                // Direct (0) and Vectored (1) are supported. Reserved MODE
                // values are WARL-coerced to Direct.
                val requestedMode = io.commit_wdata(1, 0)
                val legalMode = Mux(requestedMode === 1.U, 1.U(2.W), 0.U(2.W))
                mtvec := Cat(io.commit_wdata(XLEN - 1, 2), legalMode)
                if(dumplog){
                    printf(cf"[INFO] mtvec = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.mepc.U){
                mepc := (if (enableCompressed) Cat(io.commit_wdata(XLEN - 1, 1), 0.U(1.W))
                    else Cat(io.commit_wdata(XLEN - 1, 2), 0.U(2.W)))
                if(dumplog){
                    printf(cf"[INFO] mepc = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.mcause.U){
                mcause := io.commit_wdata
                if(dumplog){
                    printf(cf"[INFO] mcause = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.mtval.U){
                mtval := io.commit_wdata
                if(dumplog){
                    printf(cf"[INFO] mtval = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.mscratch.U){
                mscratch := io.commit_wdata
                if(dumplog){
                    printf(cf"[INFO] mscratch = 0x${io.commit_wdata}%x\n")
                }
            }
            is(CSRMAP.mstatus.U){
                mstatus_MIE  := io.commit_wdata(3)
                mstatus_MPIE := io.commit_wdata(7)
                if (enableSupervisorUser) {
                    mstatus_SIE := io.commit_wdata(1)
                    mstatus_SPIE := io.commit_wdata(5)
                    mstatus_SPP := io.commit_wdata(8)
                    val requestedMpp = io.commit_wdata(12, 11)
                    mstatus_MPP := Mux(requestedMpp === 2.U,
                        PRIV_MODE.U.U, requestedMpp)
                    mstatus_TVM := io.commit_wdata(20)
                    mstatus_TW := io.commit_wdata(21)
                    mstatus_TSR := io.commit_wdata(22)
                    mstatus_MPRV := io.commit_wdata(17)
                    mstatus_SUM := io.commit_wdata(18)
                    mstatus_MXR := io.commit_wdata(19)
                } else {
                    mstatus_MPP := io.commit_wdata(12, 11)
                }
                mstatus_FS   := io.commit_wdata(14, 13)
                if(dumplog){
                    printf(cf"[INFO] mstatus write: MIE=${io.commit_wdata(3)} MPIE=${io.commit_wdata(7)} MPP=${io.commit_wdata(12,11)}\n")
                }
            }
            is(CSRMAP.medeleg.U) {
                if (enableSupervisorUser) medeleg := io.commit_wdata & medelegMask
            }
            is(CSRMAP.mideleg.U) {
                if (enableSupervisorUser) mideleg := io.commit_wdata & midelegMask
            }
            is(CSRMAP.mie.U){
                mie_MSIE := io.commit_wdata(MACHINE_INTERRUPT_CAUSE.SOFTWARE)
                mie_MTIE := io.commit_wdata(MACHINE_INTERRUPT_CAUSE.TIMER)
                mie_MEIE := io.commit_wdata(MACHINE_INTERRUPT_CAUSE.EXTERNAL)
                if (enableSupervisorUser) {
                    mie_SSIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
                    mie_STIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.TIMER)
                    mie_SEIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL)
                }
            }
            is(CSRMAP.mip.U){
                // MSIP, MTIP and MEIP are read-only reflections of platform
                // inputs (software clears MSIP through the CLINT msip word).
                if (enableSupervisorUser) {
                    sip_SSIP := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
                    mip_SEIP := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL)
                    when(!menvcfg(63)) {
                        mip_STIP := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.TIMER)
                    }
                }
            }
            is(CSRMAP.mcounteren.U) {
                if (enableSupervisorUser) mcounteren := io.commit_wdata(31, 0)
            }
            is(CSRMAP.sstatus.U) {
                if (enableSupervisorUser) {
                    mstatus_SIE := io.commit_wdata(1)
                    mstatus_SPIE := io.commit_wdata(5)
                    mstatus_SPP := io.commit_wdata(8)
                    mstatus_SUM := io.commit_wdata(18)
                    mstatus_MXR := io.commit_wdata(19)
                    mstatus_FS := io.commit_wdata(14, 13)
                }
            }
            is(CSRMAP.sie.U) {
                if (enableSupervisorUser) {
                    when(mideleg(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)) {
                        mie_SSIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
                    }
                    when(mideleg(SUPERVISOR_INTERRUPT_CAUSE.TIMER)) {
                        mie_STIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.TIMER)
                    }
                    when(mideleg(SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL)) {
                        mie_SEIE := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL)
                    }
                }
            }
            is(CSRMAP.stvec.U) {
                if (enableSupervisorUser) {
                    val legalMode = Mux(io.commit_wdata(1, 0) === 1.U, 1.U(2.W), 0.U(2.W))
                    stvec := Cat(io.commit_wdata(XLEN - 1, 2), legalMode)
                }
            }
            is(CSRMAP.scounteren.U) {
                if (enableSupervisorUser) scounteren := io.commit_wdata(31, 0)
            }
            is(CSRMAP.sscratch.U) {
                if (enableSupervisorUser) sscratch := io.commit_wdata
            }
            is(CSRMAP.sepc.U) {
                if (enableSupervisorUser) {
                    sepc := (if (enableCompressed) Cat(io.commit_wdata(XLEN - 1, 1), 0.U(1.W))
                        else Cat(io.commit_wdata(XLEN - 1, 2), 0.U(2.W)))
                }
            }
            is(CSRMAP.scause.U) {
                if (enableSupervisorUser) scause := io.commit_wdata
            }
            is(CSRMAP.stval.U) {
                if (enableSupervisorUser) stval := io.commit_wdata
            }
            is(CSRMAP.sip.U) {
                if (enableSupervisorUser) {
                    when(mideleg(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)) {
                        sip_SSIP := io.commit_wdata(SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE)
                    }
                }
            }
            is(CSRMAP.satp.U) {
                if (enableSupervisorUser) {
                    // RV64 satp implements Bare (0) and Sv39 (8), ASID[15:0]
                    // and the 44-bit root PPN. Unsupported MODE ignores the
                    // entire write, preserving the previous address space.
                    when(io.commit_wdata(63, 60) === 8.U) {
                        satp := io.commit_wdata
                    }.elsewhen(io.commit_wdata(63, 60) === 0.U) {
                        satp := 0.U
                    }
                }
            }
            is(CSRMAP.mcycle.U, CSRMAP.minstret.U){
                // Updated in the performance block with explicit-write priority.
            }
            is(CSRMAP.menvcfg.U) {
                if (enableSupervisorUser) {
                    // Sstc STCE and Svadu ADUE are the implemented fields.
                    menvcfg := io.commit_wdata & ((BigInt(1) << 63) | (BigInt(1) << 61)).U
                }
            }
            is(CSRMAP.stimecmp.U) {
                if (enableSupervisorUser) {
                    stimecmp := io.commit_wdata
                }
            }
        }
    }
    val trapDelegated = if (enableSupervisorUser) {
        currentPrivilege =/= PRIV_MODE.M.U && Mux(
            io.trap.is_interrupt,
            mideleg(io.trap.cause(5, 0)),
            medeleg(io.trap.cause(5, 0)))
    } else false.B
    val mtvecBase = Cat(mtvec(XLEN - 1, 2), 0.U(2.W))
    val stvecBase = Cat(stvec(XLEN - 1, 2), 0.U(2.W))
    val machineTrapTarget = Mux(io.trap.is_interrupt && mtvec(1, 0) === 1.U,
        mtvecBase + (io.trap.cause << 2), mtvecBase)
    val supervisorTrapTarget = Mux(io.trap.is_interrupt && stvec(1, 0) === 1.U,
        stvecBase + (io.trap.cause << 2), stvecBase)

    // Trap entry is precise at WB. A trap raised in M is never delegated.
    // Trap entry dominates returns even if the input requests overlap.
    when(io.trap.valid){
        when(trapDelegated) {
            sepc := (if (enableCompressed) Cat(io.trap.pc(XLEN - 1, 1), 0.U(1.W))
                else Cat(io.trap.pc(XLEN - 1, 2), 0.U(2.W)))
            scause := io.trap.cause | (io.trap.is_interrupt.asUInt << (XLEN - 1))
            stval := Mux(io.trap.is_interrupt, 0.U, io.trap.tval)
            mstatus_SPIE := mstatus_SIE
            mstatus_SIE := false.B
            mstatus_SPP := currentPrivilege === PRIV_MODE.S.U
            currentPrivilege := PRIV_MODE.S.U
        }.otherwise {
            mepc := (if (enableCompressed) Cat(io.trap.pc(XLEN - 1, 1), 0.U(1.W))
                else Cat(io.trap.pc(XLEN - 1, 2), 0.U(2.W)))
            mcause := io.trap.cause | (io.trap.is_interrupt.asUInt << (XLEN - 1))
            mtval := Mux(io.trap.is_interrupt, 0.U, io.trap.tval)
            mstatus_MPIE := mstatus_MIE
            mstatus_MIE  := false.B
            mstatus_MPP  := Mux(enableSupervisorUser.B,
                currentPrivilege, PRIV_MODE.M.U)
            currentPrivilege := PRIV_MODE.M.U
        }
    }.elsewhen(io.mret_commit){
        mstatus_MIE  := mstatus_MPIE
        mstatus_MPIE := true.B
        if (enableSupervisorUser) {
            currentPrivilege := mstatus_MPP
            when(mstatus_MPP =/= PRIV_MODE.M.U) { mstatus_MPRV := false.B }
            mstatus_MPP := PRIV_MODE.U.U
        } else {
            currentPrivilege := PRIV_MODE.M.U
            mstatus_MPP := PRIV_MODE.M.U
        }
    }.elsewhen(io.sret_commit && enableSupervisorUser.B) {
        mstatus_SIE := mstatus_SPIE
        mstatus_SPIE := true.B
        currentPrivilege := Mux(mstatus_SPP, PRIV_MODE.S.U, PRIV_MODE.U.U)
        mstatus_SPP := false.B
        mstatus_MPRV := false.B
    }
    if (useFASE) {
        // Destructive debug takeover, NOT an architectural interrupt. Keep trap
        // CSRs intact for diagnosis; software owns any subsequent restoration.
        when(io.faseEnter.get) {
            currentPrivilege := PRIV_MODE.M.U
            mstatus_MPRV := false.B
            mstatus_MIE := false.B
        }
        io.faseDiagnostic.get := VecInit(Seq(currentPrivilege, mstatus_read,
            satp, mepc, mcause, mtval, sepc, scause, stval, mie_read, mip_read, mtvec))
    }
    io.csr_old_data := old_csr_val
    io.csr_new_data := new_csr_val
    io.csr_write_en := write_csr
    io.mtvec := mtvec
    io.mepc_out := mepc
    io.trap_target := Mux(trapDelegated, supervisorTrapTarget, machineTrapTarget)
    io.xret_target := Mux(io.sret_commit && !io.mret_commit, sepc, mepc)
    io.current_privilege := currentPrivilege
    io.mret_illegal := enableSupervisorUser.B && currentPrivilege =/= PRIV_MODE.M.U
    io.sret_illegal := !enableSupervisorUser.B ||
        currentPrivilege === PRIV_MODE.U.U ||
        (currentPrivilege === PRIV_MODE.S.U && mstatus_TSR)
    io.wfi_illegal := !enableSupervisorUser.B ||
        currentPrivilege === PRIV_MODE.U.U ||
        (currentPrivilege === PRIV_MODE.S.U && mstatus_TW)
    io.sfence_vma_illegal := !enableSupervisorUser.B ||
        currentPrivilege === PRIV_MODE.U.U ||
        (currentPrivilege === PRIV_MODE.S.U && mstatus_TVM)
    io.mmu_context.satp := satp
    io.mmu_context.privilege := currentPrivilege
    io.mmu_context.mprv := mstatus_MPRV
    io.mmu_context.mpp := mstatus_MPP
    io.mmu_context.sum := mstatus_SUM
    io.mmu_context.mxr := mstatus_MXR
    io.mmu_context.adue := menvcfg(61)
    io.mmu_context.pmpcfg := visiblePmpCfg
    io.mmu_context.pmpaddr := visiblePmpAddr
    io.mmu_context.pmpRanges := pmpRanges
    io.mmu_context.pmpRangesValid := true.B
    // Commit permission selects register updates after candidate decoding.
    // A rejected/trapped write changes neither raw nor decoded PMP state.
    val pmpStateWrite = io.commit_valid && io.commit_write_en && !io.trap.valid &&
        (io.commit_addr === CSRMAP.pmpcfg0.U || io.commit_addr === CSRMAP.pmpcfg2.U ||
         (io.commit_addr >= CSRMAP.pmpaddr0.U &&
          io.commit_addr < (CSRMAP.pmpaddr0 + BreezePmpConfig.ActiveEntries).U))
    when(pmpStateWrite) {
        for (index <- 0 until BreezePmpConfig.ActiveEntries) {
            pmpcfg(index) := candidatePmpCfg(index)
            pmpaddr(index) := candidatePmpAddr(index)
            pmpRanges(index) := candidatePmpRanges(index)
        }
    }
    when(!reset.asBool) {
        for (index <- 0 until BreezePmpConfig.ActiveEntries) {
            assert(pmpRanges(index).asUInt === flow.mmu.BreezePmpDecode.range(
                pmpcfg(index), pmpaddr(index),
                if (index == 0) 0.U(54.W) else pmpaddr(index - 1)).asUInt,
                "[SOC3d PMP] decoded ranges differ from architectural PMP state")
        }
    }
    // One event register, aligned with the newly committed CSR/privilege state.
    // Conservatively invalidate even an unchanged or locked PMP write; no
    // comparison of the wide PMP context is on the cache's S2 control path.
    val permissionWrite = io.commit_valid && io.commit_write_en && !io.trap.valid &&
        (io.commit_addr === CSRMAP.mstatus.U ||
         io.commit_addr === CSRMAP.pmpcfg0.U || io.commit_addr === CSRMAP.pmpcfg2.U ||
         (io.commit_addr >= CSRMAP.pmpaddr0.U &&
          io.commit_addr < (CSRMAP.pmpaddr0 + BreezePmpConfig.CsrEntries).U))
    val permissionUpdate = permissionWrite || io.trap.valid || io.mret_commit ||
        (io.sret_commit && enableSupervisorUser.B) ||
        (if (useFASE) io.faseEnter.get else false.B)
    io.mmu_context.permissionEvent := RegNext(permissionUpdate, false.B)
    io.frm := frm
    io.fp_enabled := mstatus_FS =/= 0.U
    // M-targeted interrupts precede S-targeted interrupts. Within each
    // destination use MEI > MSI > MTI > SEI > SSI > STI. Delegation controls
    // the target, not whether a supervisor interrupt source exists.
    val machineGlobalEnable = currentPrivilege =/= PRIV_MODE.M.U || mstatus_MIE
    val supervisorGlobalEnable = enableSupervisorUser.B &&
        (currentPrivilege === PRIV_MODE.U.U ||
          (currentPrivilege === PRIV_MODE.S.U && mstatus_SIE))
    val machineSources = Seq(MACHINE_INTERRUPT_CAUSE.EXTERNAL,
        MACHINE_INTERRUPT_CAUSE.SOFTWARE, MACHINE_INTERRUPT_CAUSE.TIMER)
    val supervisorSources = Seq(SUPERVISOR_INTERRUPT_CAUSE.EXTERNAL,
        SUPERVISOR_INTERRUPT_CAUSE.SOFTWARE, SUPERVISOR_INTERRUPT_CAUSE.TIMER)
    val machineCandidates = (machineSources ++ supervisorSources).map { cause =>
        val delegated = if (supervisorSources.contains(cause)) mideleg(cause) else false.B
        (machineGlobalEnable && !delegated && mie_read(cause) && mip_read(cause), cause)
    }
    val supervisorCandidates = supervisorSources.map { cause =>
        (supervisorGlobalEnable && mideleg(cause) && mie_read(cause) && mip_read(cause), cause)
    }
    val interruptCandidates = machineCandidates ++ supervisorCandidates
    io.interruptPending := interruptCandidates.map(_._1).reduce(_ || _)
    io.interruptCause := MuxCase(MACHINE_INTERRUPT_CAUSE.TIMER.U(XLEN.W),
        interruptCandidates.map { case (pending, cause) => pending -> cause.U(XLEN.W) })
    io.debug.foreach { debug =>
        debug.mcause := mcause
        debug.mepc  := mepc
    }
}
