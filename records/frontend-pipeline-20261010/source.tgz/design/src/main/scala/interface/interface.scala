package flow.interface

import chisel3._
import chisel3.util._
import flow.core._
import flow.config.BreezePmpConfig

object FlowConst{
    val pc_addr_width = 64
}

object BranchPredictConst {
    def phtIdxWidth(ghrLength: Int): Int = if (ghrLength > 0) ghrLength else 1
}

// This file stores native interfaces.
/**
  * 这个接口负责连接cache到一个虚拟的内存系统，提供地址和数据的输入输出
  * 这个接口仅仅用于仿真环境，实际的硬件设计中会使用更复杂的接口（比如AXI或者Wishbone）
  * 应该使用split-event接口，地址和数据分开传输
  *
  * === Burst 传输约定 ===
  * 本接口实现了隐式的 burst 传输模式：
  *
  * 1. Cache 发送一个 cache line 的起始地址（通过 NativeMemIO.speak()）
  * 2. 内存系统自动返回该 cache line 的所有数据（通过多次 NativeMemIO.listen()）
  * 3. 对于 32 字节的 cache line，总线宽度 64-bit 时：
  *    - 发送 1 次地址请求（例如：0x1000）
  *    - 接收 4 次数据响应：
  *      * beat 0: addr 0x1000 的 8 字节
  *      * beat 1: addr 0x1008 的 8 字节
  *      * beat 2: addr 0x1010 的 8 字节
  *      * beat 3: addr 0x1018 的 8 字节
  *
  * 4. 地址自动递增规则：
  *    - 起始地址必须是 cache line 对齐的（低 5 位为 0）
  *    - 每个 beat 地址递增 8 字节（总线宽度）
  *    - 内存模型负责自动管理地址递增
  *
  * 5. 握手协议：
  *    - 每个 beat 的数据传输都遵循标准的 ready-valid 握手
  *    - Cache 通过 listen() 接收每个 beat，直到收齐完整的 cache line
  *
  * 注意：
  * - 这是简化的仿真接口，burst length 是隐式固定的（由 cache line 大小决定）
  * - 真实硬件接口（如 AXI）会显式包含 burst length、burst type 等信号
  * - 当前约定：32-byte cache line = 4 beats（4 × 8 bytes）
  */
class NativeReqIO(val addr_width: Int) extends Bundle {
    val addr = UInt(addr_width.W)
}

class NativeRespIO(val data_width: Int) extends Bundle {
    val data = UInt(data_width.W)
}

/** CPU memory operation kind carried on the Backend->D$ request.
  *
  * Load/Store keep the historical semantics. Lr/Sc/Amo are the RV64A
  * operations; they are only legal on naturally aligned W/D addresses in a
  * cacheable, non-device PMA region (the D$ returns an access error
  * otherwise and the backend maps it to cause 5/7).
  */
object BreezeMemOp extends ChiselEnum {
    val Load, Store, Lr, Sc, Amo = Value
}

/** RV64A AMO function, decoded from funct5. */
object BreezeAmoFunc extends ChiselEnum {
    val Swap, Add, Xor, And, Or, Min, Max, MinU, MaxU = Value
    // Internal PTW operation, never decoded from an instruction. Compare the
    // entire 64-bit PTE against wdata; on equality set A/D selected by wmask.
    // Return the old PTE on both success and failure. No LR/SC reservation.
    val PteSetAd = Value
}

class BackendMemReq(val VLEN: Int = FlowConst.pc_addr_width) extends Bundle {
    val valid = Bool()
    val isWrite = Bool()
    // Original byte address. Alignment belongs to the cache/bus layer so PMA
    // checks and mtval keep the architecturally visible address.
    val addr = UInt(VLEN.W)
    val sizeLog2 = UInt(3.W)
    val wdata = UInt(64.W)
    val wmask = UInt(8.W)
    // RV64A sideband. memOp=Load/Store leaves the historical behaviour
    // untouched (isWrite must equal memOp===Store then).
    //   Lr : like a load; additionally sets the hart's reservation.
    //   Sc : wdata/wmask are pre-positioned like a store; rsp.data = 0 on
    //        success, 1 on failure (no extraction in the backend).
    //   Amo: wdata carries the RAW rs2 value (not shifted); wmask is ignored,
    //        the D$ positions the operand itself. rsp.data returns the
    //        pre-modification aligned 64-bit word, extracted/sign-extended by
    //        the backend exactly like a load of the same size.
    val memOp = BreezeMemOp()
    val amoFunc = BreezeAmoFunc()
    // Fence semantics of the atomic (aq/rl). The blocking single-outstanding
    // backend enforces them by construction; the bits are carried so the
    // ordering point stays explicit and assertable.
    val aq = Bool()
    val rl = Bool()
}

class BackendMemResp extends Bundle {
    val valid = Bool()
    val data = UInt(64.W)
    val isWriteAck = Bool()
    val error = Bool()
    val pageFault = Bool()
    val faultAddr = UInt(64.W)
}

class BackendMemIO(val VLEN: Int = FlowConst.pc_addr_width) extends Bundle {
    val req = new BackendMemReq(VLEN)
    val rsp = Flipped(new BackendMemResp)
}

class ICacheReq extends Bundle{
    val addr = UInt(FlowConst.pc_addr_width.W)
}

class ICacheResp extends Bundle{
    val data = UInt(32.W)
}

class FrontendRedirectIO(val VLEN: Int = 64) extends Bundle {
    val valid = Bool()
    val flush = Bool()
    val cacheFlush = Bool()
    val target = UInt(VLEN.W)
}

object FrontendPredType extends ChiselEnum {
    val NONE, BR, JAL, JALR = Value
}

class FrontendPredInfo(val VLEN: Int = 64, val ghrLength: Int = 0) extends Bundle {
    val predType = FrontendPredType()
    val predTaken = Bool()
    val predPc = UInt(VLEN.W)
    val phtIdx = UInt(BranchPredictConst.phtIdxWidth(ghrLength).W)
}

class BreezePHTPredictReq(val vlen: Int, val ghrLength: Int) extends Bundle {
    val valid = Bool()
    val pc = UInt(vlen.W)
    val ghr = UInt(ghrLength.W)
}

class BreezePHTPredictResp(val ghrLength: Int) extends Bundle {
    val valid = Bool()
    val taken = Bool()
    val idx = UInt(ghrLength.W)
}

class BreezePHTUpdateReq(val ghrLength: Int) extends Bundle {
    val valid = Bool()
    val idx = UInt(ghrLength.W)
    val taken = Bool()
}

class BreezeGHRUpdateReq extends Bundle {
    val valid = Bool()
    val taken = Bool()
}

class BreezeBTBLookupReq(val vlen: Int) extends Bundle {
    val pc = UInt(vlen.W)
}

class BreezeBTBLookupResp(val vlen: Int) extends Bundle {
    val hit = Bool()
    val taken = Bool()
    val predType = FrontendPredType()
    val target = UInt(vlen.W)
}

class BreezeBTBUpdateReq(val vlen: Int) extends Bundle {
    val valid = Bool()
    val pc = UInt(vlen.W)
    val target = UInt(vlen.W)
    val predType = FrontendPredType()
    val taken = Bool()
}

class FrontendFetchBundle(val VLEN: Int = 64, val ghrLength: Int = 0) extends Bundle {
    val pc = UInt(VLEN.W)
    val inst = UInt(32.W)
    val rawInst = UInt(32.W)
    val instLen = UInt(3.W)
    val isCompressed = Bool()
    val illegalCompressed = Bool()
    val instructionAccessFault = Bool()
    val instructionPageFault = Bool()
    val instructionFaultSecondParcel = Bool()
    val pred = new FrontendPredInfo(VLEN, ghrLength)
}

class FrontendFetchBufferIO(val VLEN: Int = 64, val ghrLength: Int = 0) extends Bundle {
    val valid = Output(Bool())
    val bits = Output(new FrontendFetchBundle(VLEN, ghrLength))
    val canAccept3 = Input(Bool())
}

class BackendDebugIO(val VLEN: Int = 64) extends Bundle {
    val decodeValid = Output(Bool())
    val decodeInst = Output(UInt(32.W))
    val decodePc = Output(UInt(VLEN.W))
    val idExeValid = Output(Bool())
    val idExeInst = Output(UInt(32.W))
    val idExePc = Output(UInt(VLEN.W))
    val idExeRs1Addr = Output(UInt(5.W))
    val idExeRs2Addr = Output(UInt(5.W))
    val idExeSrc1 = Output(UInt(VLEN.W))
    val idExeSrc2 = Output(UInt(VLEN.W))
    val exeSrc1 = Output(UInt(VLEN.W))
    val exeSrc2 = Output(UInt(VLEN.W))
    val exeAluOut = Output(UInt(VLEN.W))
    val exeBruTaken = Output(Bool())
    val exeJumpAddr = Output(UInt(VLEN.W))
    val exeMemValid = Output(Bool())
    val exeMemPc = Output(UInt(VLEN.W))
    val exeMemData = Output(UInt(VLEN.W))
    val exeMemRdAddr = Output(UInt(5.W))
    val memWaitingResp = Output(Bool())
    val memWbValid = Output(Bool())
    val memWbPc = Output(UInt(VLEN.W))
    val memWbInst = Output(UInt(32.W))
    val wbData = Output(UInt(VLEN.W))
    val exeBypassRs1 = Output(UInt(VLEN.W))
    val exeBypassRs2 = Output(UInt(VLEN.W))
    val loadUseHazard = Output(Bool())
    val redirectValid = Output(Bool())
    val csrMtvec       = Output(UInt(VLEN.W))
    val csrMcause      = Output(UInt(VLEN.W))
    val csrMepc        = Output(UInt(VLEN.W))
    val memWbException = Output(Bool())
    val memWbTrapValid = Output(Bool())
    val memWbIsEcall = Output(Bool())
    val memWbIsMret = Output(Bool())
    val memWbIsWfi = Output(Bool())
    val wfiSleeping = Output(Bool())
    val csrIllegal = Output(Bool())
}

class TracePayload(val VLEN: Int = 64) extends Bundle {
    val valid = Bool()
    val pc = UInt(VLEN.W)
    val inst = UInt(32.W)
    val nextPc = UInt(VLEN.W)
    val estop = Bool()
    val rdWriteEn = Bool()
    val rdAddr = UInt(5.W)
    val rdData = UInt(VLEN.W)
    val memEn = Bool()
    val memIsWrite = Bool()
    val memAddr = UInt(VLEN.W)
    val memAlignedAddr = UInt(VLEN.W)
    val memRData = UInt(VLEN.W)
    val memWData = UInt(64.W)
    val memWMask = UInt(8.W)
    val rdPending = Bool()
    val rdIsFp = Bool()
    val lateWriteValid = Bool()
    val lateWriteIsFp = Bool()
    val lateWriteError = Bool()
    val lateWriteRd = UInt(5.W)
    val lateWriteData = UInt(64.W)
}

/** Simulation/debug view of one blocking L1D transaction.
  *
  * The payload is observational only: it has no ready input and cannot add
  * backpressure to the cache. `requestValid` pulses in Lookup after the PMA
  * and tag result are available; `responseValid` pulses when the CPU response
  * is presented. Since the cache is blocking, at most one transaction per
  * hart is represented between those pulses.
  */
class DCacheTracePayload(val VLEN: Int = 64) extends Bundle {
    val requestValid = Bool()
    val responseValid = Bool()
    val address = UInt(VLEN.W)
    val sizeLog2 = UInt(3.W)
    val isWrite = Bool()
    val writeData = UInt(64.W)
    val mask = UInt(8.W)
    val pmaAllowed = Bool()
    val pmaCacheable = Bool()
    val pmaDevice = Bool()
    val cacheHit = Bool()
    val responseData = UInt(64.W)
    val responseError = Bool()
}

class CSRTrapInfo(val XLEN: Int = 64) extends Bundle {
    val valid        = Bool()
    val is_interrupt = Bool()
    val cause        = UInt(XLEN.W)
    val pc           = UInt(XLEN.W)
    val tval         = UInt(XLEN.W)
}

/** CSR-derived PMP interval; all arithmetic is done at the CSR write edge. */
class BreezePmpRange extends Bundle {
    val lower = UInt(65.W)
    val upper = UInt(65.W)
    val lowerBlockPrevious = UInt(58.W)
    val upperBlockPrevious = UInt(58.W)
    val nonempty = Bool()
}

/** Privileged translation state exported by the CSR file. */
class BreezeMmuContext(val XLEN: Int = 64) extends Bundle {
    val satp = UInt(XLEN.W)
    val privilege = UInt(PRIV_MODE.width.W)
    val mprv = Bool()
    val mpp = UInt(PRIV_MODE.width.W)
    val sum = Bool()
    val mxr = Bool()
    val adue = Bool()
    val pmpcfg = Vec(BreezePmpConfig.CsrEntries, UInt(8.W))
    val pmpaddr = Vec(BreezePmpConfig.CsrEntries, UInt(54.W))
    val pmpRanges = Vec(BreezePmpConfig.ActiveEntries, new BreezePmpRange)
    // CSRFile drives true. Raw-context clients can leave this false and use
    // the checker's combinational decoder without changing their CSR layout.
    val pmpRangesValid = Bool()
    // Registered by CSRFile at the same edge as the permission-state update.
    // Consumers must not register this pulse again.
    val permissionEvent = Bool()
}

class BreezeSfenceReq(val XLEN: Int = 64) extends Bundle {
    val valid = Bool()
    val vaddr = UInt(XLEN.W)
    val asid = UInt(16.W)
    val useVaddr = Bool()
    val useAsid = Bool()
}

object BreezeMmuAccess extends ChiselEnum {
    val Fetch, Load, Store = Value
}

class BreezeTranslationReq(val XLEN: Int = 64) extends Bundle {
    val vaddr = UInt(XLEN.W)
    val access = BreezeMmuAccess()
    val sizeLog2 = UInt(3.W)
}

class BreezeTranslationResp(val XLEN: Int = 64) extends Bundle {
    val vaddr = UInt(XLEN.W)
    val paddr = UInt(XLEN.W)
    val pageFault = Bool()
    val accessFault = Bool()
}

class BreezeTranslationPort(val XLEN: Int = 64) extends Bundle {
    val req = Flipped(Decoupled(new BreezeTranslationReq(XLEN)))
    val resp = Decoupled(new BreezeTranslationResp(XLEN))
}

/** One-cycle occurrence pulses plus per-cycle stall levels consumed by HPM. */
class BreezeHpmEvents extends Bundle {
    val controlRetired = Bool()
    val controlTaken = Bool()
    val predictionMiss = Bool()
    val icacheAccess = Bool()
    val icacheMiss = Bool()
    val dcacheAccess = Bool()
    val dcacheMiss = Bool()
    val dcacheUncached = Bool()
    val memStallCycle = Bool()
    val loadUseStall = Bool()
    val mulSourceStall = Bool()
    val divSourceStall = Bool()
    val wbPortConflict = UInt(2.W)
}

class CSRFDebugIO(val XLEN: Int = 64) extends Bundle {
    val mcause = Output(UInt(XLEN.W))
    val mepc   = Output(UInt(XLEN.W))
}

class BreezeBackendIDEXE(val VLEN: Int = 64, val ghrLength: Int = 0) extends Bundle {
    val valid = Bool()
    val pc = UInt(VLEN.W)
    val inst = UInt(32.W)
    val rawInst = UInt(32.W)
    val instLen = UInt(3.W)
    val instruction_access_fault = Bool()
    val instruction_page_fault = Bool()
    val instruction_fault_second_parcel = Bool()
    val illegal_inst = Bool()
    val is_ecall = Bool()
    val is_ebreak = Bool()
    val is_mret  = Bool()
    val is_sret  = Bool()
    val is_wfi   = Bool()
    val pred = new FrontendPredInfo(VLEN, ghrLength)
    val ctrl = new EXE_Ctrl
    val estop = Bool()
    val rs1_addr = UInt(5.W)
    val rs2_addr = UInt(5.W)
    val rd_addr = UInt(5.W)
    val rs1_data = UInt(VLEN.W)
    val rs2_data = UInt(VLEN.W)
    val imm = UInt(VLEN.W)
    val src1 = UInt(VLEN.W)
    val src2 = UInt(VLEN.W)
}

class BreezeBackendEXEMEM(val VLEN: Int = 64, val ghrLength: Int = 0, val enableTandem: Boolean = false) extends Bundle {
    val valid = Bool()
    val pc = UInt(VLEN.W)
    val nextPc = UInt(VLEN.W)
    val inst = UInt(32.W)
    val rawInst = UInt(32.W)
    val instLen = UInt(3.W)
    val instruction_access_fault = Bool()
    val instruction_page_fault = Bool()
    val instruction_fault_second_parcel = Bool()
    val illegal_inst = Bool()
    val is_ecall = Bool()
    val is_ebreak = Bool()
    val is_mret  = Bool()
    val is_sret  = Bool()
    val is_wfi   = Bool()
    val csr_illegal = Bool()
    val pred = new FrontendPredInfo(VLEN, ghrLength)
    val estop = Bool()
    val fencei = Bool()
    val data = UInt(VLEN.W)
    val rs2_data = UInt(VLEN.W)
    val mul_a = SInt(65.W)
    val mul_b = SInt(65.W)
    val mul_valid = Bool()
    val mul_op = UInt(MUL_OP.width.W)
    val div_valid = Bool()
    val div_fast = Bool()
    val div_fast_result = UInt(VLEN.W)
    val div_dividend_mag = UInt(VLEN.W)
    val div_divisor_mag = UInt(VLEN.W)
    val div_quotient_neg = Bool()
    val div_remainder_neg = Bool()
    val div_is_remainder = Bool()
    val div_is_word = Bool()
    val mem_cmd = UInt(MEM_TYPE.width.W)
    val rd_addr = UInt(5.W)
    val rs1_addr = UInt(5.W)
    val csr_addr = UInt(12.W)
    val csr_cmd = UInt(CSR_CMD.width.W)
    val wb_en = Bool()
    val wb_sel = UInt(SEL_WB.width.W)
    val actual_taken = Bool()
    val actual_target = UInt(VLEN.W)
    val prediction_miss = Bool()
    val trace = if (enableTandem) Some(new TracePayload(VLEN)) else None
}

class BreezeBackendMEMWB(val VLEN: Int = 64, val enableTandem: Boolean = false) extends Bundle {
    val valid = Bool()
    val pc = UInt(VLEN.W)
    val nextPc = UInt(VLEN.W)
    val inst = UInt(32.W)
    val rawInst = UInt(32.W)
    val instLen = UInt(3.W)
    val instruction_access_fault = Bool()
    val instruction_page_fault = Bool()
    val instruction_fault_second_parcel = Bool()
    val illegal_inst = Bool()
    val is_ecall = Bool()
    val is_ebreak = Bool()
    val is_mret  = Bool()
    val is_sret  = Bool()
    val is_wfi   = Bool()
    val csr_illegal = Bool()
    val load_addr_misaligned = Bool()
    val store_addr_misaligned = Bool()
    val load_access_fault = Bool()
    val store_access_fault = Bool()
    val load_page_fault = Bool()
    val store_page_fault = Bool()
    val estop = Bool()
    val wb_en = Bool()
    val wb_sel = UInt(SEL_WB.width.W)
    val rd_addr = UInt(5.W)
    val alu_data = UInt(VLEN.W)
    val mem_data = UInt(VLEN.W)
    val csr_data = UInt(VLEN.W)
    val mul_data = UInt(VLEN.W)
    val csr_addr = UInt(12.W)
    val csr_new_data = UInt(VLEN.W)
    val csr_write_en = Bool()
    val prediction_miss = Bool()
    val trace = if (enableTandem) Some(new TracePayload(VLEN)) else None
}

//from cache
class ICacheIO extends Bundle{
    val req = Flipped(Decoupled(new ICacheReq))
    val resp = Decoupled(new ICacheResp)
    def initialize(): Unit = {
        req.ready := false.B
        resp.valid := false.B
        resp.bits.data := 0.U
    }
}
/**
  * Native Memory IO 接口 - 用于仿真环境的内存访问接口
  *
  * 这是一个简化的 split-transaction 内存接口，支持 burst 传输：
  * - req 通道：发送地址请求（使用 speak() 方法）
  * - resp 通道：接收数据响应（使用 listen() 方法）
  *
  * Burst 模式：一个地址请求 → 多个数据响应
  * 详见上方 NativeReqIO 类注释中的 "Burst 传输约定"
  */
class NativeMemIO extends Bundle {
    val req = Decoupled(new NativeReqIO(64))
    val resp = Flipped(Decoupled(new NativeRespIO(64)))
    def speak(addr: UInt): Bool = {
        var invokecount = 0
        if(invokecount == 0){
            val done = WireDefault(false.B)
            req.bits.addr := addr
            req.valid := true.B
            when(req.ready) {
                done := true.B
            }
            invokecount += 1
            done
        } else {
            throw new Exception("NativeMemIO.request can only be invoked once in one module")
        }
    }
    def listen():(Bool,UInt) = {
        var invokecount = 0
        if(invokecount == 0){
            resp.ready := true.B
            val done = WireDefault(false.B)
            val data = WireDefault(0.U)
            when(resp.fire){
                done := true.B
                data := resp.bits.data
            }
            invokecount += 1
            (done, data)
        } else {
            throw new Exception("NativeMemIO.listen can only be invoked once in one module")
        }
    }
    def initialize(): Unit = {
        req.valid := false.B
        req.bits.addr := 0.U
        resp.ready := false.B
    }
}

class Frontend_Instruction_Bunlde(val pc_width: Int = 64) extends Bundle{
    val inst = UInt(32.W)
    val pc = UInt(pc_width.W)
    val address_misaligned = Bool()
    val access_fault = Bool()
}

class BreezeCacheReqIO(val VLEN:Int =64) extends Bundle{
    val vaddr = UInt(VLEN.W)
    val paddr = UInt(VLEN.W)
}

class BreezeCacheRespIO(val VLEN:Int = 64,val FETCH_WIDTH:Int = 32) extends Bundle{
    val data = UInt(FETCH_WIDTH.W)
    val vaddr = UInt(VLEN.W)
    val accessFault = Bool()
    val pageFault = Bool()
}
/**
  * L1 ICache当miss的时候，向下级cache发出请求的接口
  * 默认方向是以ICache的视角
  *
  * req是单周期事件脉冲，不提供ready。专用下级必须在req有效的周期
  * 无条件锁存paddr。阻塞式ICache在收到响应以前不会发出第二个请求。
  *
  */
class L1CacheMissReqIO(val PLEN:Int = 64) extends Bundle{
    val paddr = Output(UInt(PLEN.W))
    val req = Output(Bool())
}

/**
  * L1 ICache miss的时候，下级向cache的返回接口
  * 每次下一级向l1 icache返回一个cache line位宽的数据
  * 默认是32byte = 32 * 8bit = 256 bits的cache line
  * vld同样是单周期事件脉冲；ICache在等待响应期间无条件接收。
  * error表示该cache line获取失败，此时data无效且不得写入cache。
  */

class L1CacheMissRespIO(val ICACHE_LINE_WIDTH:Int = 256) extends Bundle {
    val data = Input(UInt(ICACHE_LINE_WIDTH.W))
    val vld = Input(Bool())
    val error = Input(Bool())
}

/** Blocking DCache-to-memory request, viewed from the DCache side.
  *
  * `req` is a one-cycle event pulse. The dedicated lower-level bridge must be
  * idle and capture it unconditionally. Only one transaction is outstanding.
  * Scalar transactions place their payload and byte mask in the low 64 bits.
  */
class DCacheMemReqIO(
    val PLEN: Int = 64,
    val lineBytes: Int = 32
) extends Bundle {
    val req = Output(Bool())
    val addr = Output(UInt(PLEN.W))
    val isWrite = Output(Bool())
    val isLine = Output(Bool())
    val data = Output(UInt((lineBytes * 8).W))
    val mask = Output(UInt(lineBytes.W))
}

/** Blocking DCache-to-memory response, viewed from the DCache side. */
class DCacheMemRespIO(val lineBytes: Int = 32) extends Bundle {
    val vld = Input(Bool())
    val data = Input(UInt((lineBytes * 8).W))
    val error = Input(Bool())
}

class FASECoreIO() extends Bundle {
    val instruction = Input(UInt(32.W))
    val inst_ready = Output(Bool())
    val inst_valid = Input(Bool())
    val inst_pc = Input(UInt(64.W))
    val halt = Input(Bool())
    val launch = Input(Bool())
    val launchPc = Input(UInt(64.W))
    val halted = Output(Bool())
    val empty = Output(Bool())
    val retired = Output(Bool())
    val fault = Output(Bool())
    val cause = Output(UInt(64.W))
    val tval = Output(UInt(64.W))
    val nextPc = Output(UInt(64.W))
    val regIndex = Input(UInt(5.W))
    val regWrite = Input(Bool())
    val regWdata = Input(UInt(64.W))
    val regRdata = Output(UInt(64.W))
    val diagnostic = Output(Vec(48, UInt(64.W)))
}

/** Optional backend port. Absent in production elaborations. */
class FaseBackendIO extends Bundle {
    val active = Input(Bool())
    val enter = Input(Bool())
    val launch = Input(Bool())
    val launchPc = Input(UInt(64.W))
    val regIndex = Input(UInt(5.W))
    val regWrite = Input(Bool())
    val regWdata = Input(UInt(64.W))
    val regRdata = Output(UInt(64.W))
    val empty = Output(Bool())
    val retired = Output(Bool())
    val fault = Output(Bool())
    val cause = Output(UInt(64.W))
    val tval = Output(UInt(64.W))
    val nextPc = Output(UInt(64.W))
    val diagnostic = Output(Vec(28, UInt(64.W)))
    val flightEvents = Output(Vec(4, new flow.fase.FlightEvent))
    val flightPrivilege = Output(UInt(2.W))
}
